import json
from datetime import datetime
from typing import Optional
from fastapi import WebSocket
from models.schemas import WSEvent


class ConnectionManager:
    """Manages WebSocket connections for real-time pipeline updates."""

    def __init__(self):
        # project_id -> set of websocket connections
        self.active_connections: dict[str, set[WebSocket]] = {}
        # global connections (dashboard overview)
        self.global_connections: set[WebSocket] = set()

    async def connect(self, websocket: WebSocket, project_id: Optional[str] = None):
        await websocket.accept()
        if project_id:
            if project_id not in self.active_connections:
                self.active_connections[project_id] = set()
            self.active_connections[project_id].add(websocket)
        else:
            self.global_connections.add(websocket)

    def disconnect(self, websocket: WebSocket, project_id: Optional[str] = None):
        if project_id and project_id in self.active_connections:
            self.active_connections[project_id].discard(websocket)
            if not self.active_connections[project_id]:
                del self.active_connections[project_id]
        else:
            self.global_connections.discard(websocket)

    async def send_event(self, event: WSEvent):
        """Send event to all connections watching this project + global."""
        data = event.model_dump_json()

        # Project-specific connections
        project_id = event.project_id
        if project_id in self.active_connections:
            dead = []
            for ws in self.active_connections[project_id]:
                try:
                    await ws.send_text(data)
                except Exception:
                    dead.append(ws)
            for ws in dead:
                self.active_connections[project_id].discard(ws)

        # Global connections
        dead = []
        for ws in self.global_connections:
            try:
                await ws.send_text(data)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.global_connections.discard(ws)

    async def broadcast(self, event: str, data: dict):
        """Broadcast to all global connections."""
        msg = json.dumps({"event": event, "data": data, "timestamp": datetime.utcnow().isoformat()})
        dead = []
        for ws in self.global_connections:
            try:
                await ws.send_text(msg)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.global_connections.discard(ws)


# Singleton
ws_manager = ConnectionManager()
