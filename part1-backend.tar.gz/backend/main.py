from contextlib import asynccontextmanager
from typing import Optional

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Query
from fastapi.middleware.cors import CORSMiddleware

from config import get_settings
from core.database import init_db, close_db
from core.websocket import ws_manager
from api.projects import router as projects_router
from api.pipeline import router as pipeline_router

settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup and shutdown events."""
    # Startup
    print(f"🚀 Starting {settings.app_name}...")
    await init_db()
    print("✅ Database initialized")
    yield
    # Shutdown
    await close_db()
    print("👋 Shutdown complete")


app = FastAPI(
    title="Multi-Agent E-Commerce System",
    description="Automated e-commerce pipeline powered by AI agents",
    version="1.0.0",
    lifespan=lifespan,
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# API Routes
app.include_router(projects_router, prefix="/api")
app.include_router(pipeline_router, prefix="/api")


# ──────────────────────────────────────────────
# WebSocket Endpoints
# ──────────────────────────────────────────────

@app.websocket("/ws")
async def websocket_global(websocket: WebSocket):
    """Global WebSocket - receives all pipeline events."""
    await ws_manager.connect(websocket)
    try:
        while True:
            await websocket.receive_text()  # Keep alive
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket)


@app.websocket("/ws/{project_id}")
async def websocket_project(websocket: WebSocket, project_id: str):
    """Project-specific WebSocket - receives events for one project."""
    await ws_manager.connect(websocket, project_id)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket, project_id)


# ──────────────────────────────────────────────
# Health Check
# ──────────────────────────────────────────────

@app.get("/health")
async def health():
    return {
        "status": "healthy",
        "app": settings.app_name,
        "env": settings.app_env,
    }


@app.get("/")
async def root():
    return {
        "name": "Multi-Agent E-Commerce System",
        "version": "1.0.0",
        "docs": "/docs",
        "health": "/health",
    }
