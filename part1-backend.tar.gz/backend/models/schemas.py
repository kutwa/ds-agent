from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime
from uuid import UUID
from models.database import ProjectStatus, AgentType, TaskStatus


# ──────────────────────────────────────────────
# Project Schemas
# ──────────────────────────────────────────────

class ProjectCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    niche: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = None
    config: dict = Field(default_factory=dict)


class ProjectUpdate(BaseModel):
    name: Optional[str] = None
    niche: Optional[str] = None
    description: Optional[str] = None
    status: Optional[ProjectStatus] = None
    config: Optional[dict] = None


class ProjectResponse(BaseModel):
    id: UUID
    name: str
    niche: str
    description: Optional[str]
    status: ProjectStatus
    config: dict
    shopify_store_url: Optional[str]
    shopify_store_id: Optional[str]
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class ProjectListResponse(BaseModel):
    projects: list[ProjectResponse]
    total: int


# ──────────────────────────────────────────────
# Product Schemas
# ──────────────────────────────────────────────

class ProductResponse(BaseModel):
    id: UUID
    project_id: UUID
    name: str
    description: Optional[str]
    seo_title: Optional[str]
    seo_description: Optional[str]
    price: Optional[float]
    cost: Optional[float]
    category: Optional[str]
    tags: list
    images: list
    variants: list
    shopify_product_id: Optional[str]
    is_published: bool
    trend_score: Optional[float]
    competition_score: Optional[float]
    margin_score: Optional[float]
    overall_score: Optional[float]
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


# ──────────────────────────────────────────────
# Task Schemas
# ──────────────────────────────────────────────

class TaskResponse(BaseModel):
    id: UUID
    project_id: UUID
    agent_type: AgentType
    task_name: str
    status: TaskStatus
    input_data: dict
    output_data: dict
    error_message: Optional[str]
    started_at: Optional[datetime]
    completed_at: Optional[datetime]
    duration_seconds: Optional[float]
    api_cost: float
    tokens_used: int
    requires_approval: bool
    approved_by: Optional[str]
    approved_at: Optional[datetime]
    created_at: datetime

    class Config:
        from_attributes = True


class TaskApproval(BaseModel):
    approved: bool
    approved_by: str = "admin"


# ──────────────────────────────────────────────
# Research Schemas
# ──────────────────────────────────────────────

class ResearchReportResponse(BaseModel):
    id: UUID
    project_id: UUID
    niche_analysis: dict
    competitors: list
    trending_products: list
    market_data: dict
    recommendations: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True


# ──────────────────────────────────────────────
# Pipeline Schemas
# ──────────────────────────────────────────────

class PipelineStartRequest(BaseModel):
    project_id: UUID


class PipelineStatusResponse(BaseModel):
    project_id: UUID
    status: ProjectStatus
    current_agent: Optional[AgentType]
    tasks: list[TaskResponse]
    progress_percent: float


# ──────────────────────────────────────────────
# WebSocket Event
# ──────────────────────────────────────────────

class WSEvent(BaseModel):
    event: str  # agent_started, agent_completed, agent_failed, pipeline_completed, etc.
    project_id: str
    agent_type: Optional[str] = None
    data: dict = Field(default_factory=dict)
    timestamp: datetime = Field(default_factory=datetime.utcnow)
