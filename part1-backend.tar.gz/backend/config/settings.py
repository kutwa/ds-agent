from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    # App
    app_name: str = "multi-agent-ecommerce"
    app_env: str = "development"
    app_debug: bool = True
    app_secret_key: str = "CHANGE_ME"

    # Database
    database_url: str = "postgresql+asyncpg://postgres:password@localhost:5432/agent_ecommerce"
    database_sync_url: str = "postgresql://postgres:password@localhost:5432/agent_ecommerce"

    # Redis
    redis_url: str = "redis://localhost:6379/0"
    celery_broker_url: str = "redis://localhost:6379/1"

    # Anthropic
    anthropic_api_key: str = ""
    anthropic_model: str = "claude-sonnet-4-20250514"

    # Shopify
    shopify_api_key: str = ""
    shopify_api_secret: str = ""
    shopify_access_token: str = ""
    shopify_shop_url: str = ""

    # S3
    s3_endpoint_url: str = "http://localhost:9000"
    s3_access_key: str = ""
    s3_secret_key: str = ""
    s3_bucket_name: str = "agent-ecommerce-assets"

    # Image Generation
    openai_api_key: str = ""

    # Frontend
    frontend_url: str = "http://localhost:5173"
    cors_origins: str = "http://localhost:5173,http://localhost:3000"

    @property
    def cors_origins_list(self) -> list[str]:
        return [origin.strip() for origin in self.cors_origins.split(",")]

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


@lru_cache()
def get_settings() -> Settings:
    return Settings()
