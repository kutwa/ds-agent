import asyncio
from uuid import UUID
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update

from core.database import get_db
from models.database import Project, AgentTask, TaskStatus, ProjectStatus
from models.schemas import PipelineStartRequest, TaskApproval
from agents.orchestrator import orchestrator

router = APIRouter(prefix="/pipeline", tags=["pipeline"])


@router.post("/start")
async def start_pipeline(
    data: PipelineStartRequest,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db),
):
    """Start the full agent pipeline for a project."""
    project = await db.get(Project, data.project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    if project.status not in (ProjectStatus.DRAFT, ProjectStatus.FAILED, ProjectStatus.PAUSED):
        raise HTTPException(
            status_code=400,
            detail=f"Cannot start pipeline for project in status '{project.status.value}'. "
                   f"Must be draft, failed, or paused.",
        )

    # Run pipeline in background
    background_tasks.add_task(orchestrator.run_pipeline, data.project_id)

    return {
        "message": "Pipeline started",
        "project_id": str(data.project_id),
        "status": "starting",
    }


@router.get("/status/{project_id}")
async def get_pipeline_status(project_id: UUID):
    """Get current pipeline status."""
    status = await orchestrator.get_pipeline_status(project_id)
    if "error" in status:
        raise HTTPException(status_code=404, detail=status["error"])
    return status


@router.post("/resume/{project_id}")
async def resume_pipeline(
    project_id: UUID,
    from_agent: str = "store_builder",
    background_tasks: BackgroundTasks = None,
    db: AsyncSession = Depends(get_db),
):
    """Resume a paused pipeline from a specific agent."""
    project = await db.get(Project, project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    background_tasks.add_task(orchestrator.resume_pipeline, project_id, from_agent)

    return {
        "message": f"Pipeline resuming from {from_agent}",
        "project_id": str(project_id),
    }


@router.post("/approve/{task_id}")
async def approve_task(
    task_id: UUID,
    data: TaskApproval,
    db: AsyncSession = Depends(get_db),
):
    """Approve or reject a task that requires human approval."""
    task = await db.get(AgentTask, task_id)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    if task.status != TaskStatus.AWAITING_APPROVAL:
        raise HTTPException(
            status_code=400,
            detail=f"Task is not awaiting approval (current status: {task.status.value})",
        )

    if data.approved:
        task.status = TaskStatus.APPROVED
        task.approved_by = data.approved_by
        task.approved_at = datetime.utcnow()
    else:
        task.status = TaskStatus.REJECTED

    await db.flush()

    return {
        "task_id": str(task_id),
        "status": task.status.value,
        "approved_by": data.approved_by if data.approved else None,
    }


@router.post("/stop/{project_id}")
async def stop_pipeline(project_id: UUID, db: AsyncSession = Depends(get_db)):
    """Stop/pause a running pipeline."""
    project = await db.get(Project, project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    project.status = ProjectStatus.PAUSED
    await db.flush()

    return {"message": "Pipeline paused", "project_id": str(project_id)}
