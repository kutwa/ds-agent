import json
from uuid import UUID

import httpx
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from agents.base_agent import BaseAgent
from config import get_settings
from models.database import AgentType, AgentTask, Product, Project

settings = get_settings()


COPY_SYSTEM_PROMPT = """You are an expert e-commerce copywriter and SEO specialist. You write compelling, conversion-optimized copy.

Based on the provided products and brand identity, generate ALL copy needed for the store.

Return JSON:
{
    "product_descriptions": [
        {
            "product_name": "Original product name",
            "headline": "Attention-grabbing headline",
            "short_description": "1-2 sentence hook for product cards (max 160 chars)",
            "full_description_html": "<p>Full product description with HTML formatting. 3-5 paragraphs. Include benefits, features, use cases. SEO-optimized.</p>",
            "bullet_points": ["Key feature 1", "Key feature 2", "Key feature 3", "Key feature 4"],
            "seo_title": "SEO title (max 60 chars)",
            "seo_description": "Meta description (max 155 chars)",
            "tags": ["seo", "relevant", "tags"]
        }
    ],
    "page_content": {
        "homepage": {
            "hero_headline": "Main homepage headline",
            "hero_subheadline": "Supporting text",
            "hero_cta": "Call to action button text",
            "value_props": [
                {"title": "Value Prop Title", "description": "Brief description"}
            ],
            "about_snippet": "Brief about text for homepage"
        },
        "about_page": {
            "title": "About Us",
            "content_html": "<p>Full about page content in HTML. Tell the brand story. 3-4 paragraphs.</p>"
        },
        "shipping_page": {
            "title": "Shipping & Returns",
            "content_html": "<p>Shipping policy and returns information.</p>"
        },
        "faq": [
            {
                "question": "Frequently asked question",
                "answer": "Detailed answer"
            }
        ]
    },
    "email_templates": {
        "welcome": {
            "subject": "Welcome email subject line",
            "body_html": "<p>Welcome email body. Warm, on-brand, with CTA.</p>"
        },
        "abandoned_cart": {
            "subject": "Abandoned cart subject line",
            "body_html": "<p>Abandoned cart recovery email.</p>"
        },
        "order_confirmation": {
            "subject": "Order confirmation subject",
            "body_html": "<p>Order confirmation email.</p>"
        }
    },
    "social_media": {
        "instagram_bio": "Instagram bio (max 150 chars)",
        "social_posts": [
            {
                "platform": "instagram",
                "caption": "Post caption with hashtags",
                "type": "product-showcase/lifestyle/educational/promotional"
            }
        ]
    }
}

Write in the brand's voice. Be persuasive but authentic. Every word should serve conversion or SEO."""


class CopyAgent(BaseAgent):
    agent_type = AgentType.COPY
    agent_name = "Copy Agent"

    @property
    def requires_approval(self) -> bool:
        return True

    async def execute(
        self, db: AsyncSession, project_id: UUID, context: dict, task: AgentTask
    ) -> dict:
        project = await db.get(Project, project_id)

        # Get products
        result = await db.execute(
            select(Product).where(Product.project_id == project_id)
        )
        products = result.scalars().all()

        # Step 1: Generate all copy
        await self.emit_event(project_id, "agent_progress", {
            "agent": self.agent_name, "step": "Writing product descriptions...", "progress": 10,
        })

        products_info = [
            {
                "name": p.name,
                "description": p.description,
                "price": p.price,
                "category": p.category,
                "tags": p.tags,
            }
            for p in products
        ]

        brand_identity = context.get("brand_identity", {})
        seo_keywords = context.get("seo_keywords", [])
        store_config = context.get("store_config", {})

        user_message = f"""Write all copy for this e-commerce store:

Store: {project.name}
Niche: {project.niche}
Brand voice: {brand_identity.get('brand_voice', 'Professional and trustworthy')}
Brand style: {json.dumps(brand_identity.get('style_keywords', []))}
SEO target keywords: {json.dumps(seo_keywords)}
Store config: {json.dumps(store_config)}

Products to write for:
{json.dumps(products_info, indent=2)}

Write compelling, SEO-optimized copy for every product and page. 
Use the brand voice consistently. Focus on benefits over features.
Include relevant keywords naturally."""

        copy_data, tokens1, cost1 = await self.call_claude_json(
            COPY_SYSTEM_PROMPT, user_message, max_tokens=8000, temperature=0.7
        )

        await self.emit_event(project_id, "agent_progress", {
            "agent": self.agent_name, "step": "Applying copy to products...", "progress": 60,
        })

        # Step 2: Update products in DB with generated copy
        product_descriptions = copy_data.get("product_descriptions", [])
        updated_count = 0

        for desc in product_descriptions:
            for product in products:
                if product.name.lower() in desc.get("product_name", "").lower() or \
                   desc.get("product_name", "").lower() in product.name.lower():
                    product.description = desc.get("full_description_html", product.description)
                    product.seo_title = desc.get("seo_title", product.seo_title)
                    product.seo_description = desc.get("seo_description")
                    product.tags = desc.get("tags", product.tags)
                    updated_count += 1
                    break

        # Step 3: Update Shopify products with new descriptions
        await self.emit_event(project_id, "agent_progress", {
            "agent": self.agent_name, "step": "Syncing copy to Shopify...", "progress": 80,
        })

        synced_count = 0
        if settings.shopify_access_token:
            async with httpx.AsyncClient(timeout=30.0) as client:
                for product in products:
                    if product.shopify_product_id:
                        try:
                            resp = await client.put(
                                f"https://{settings.shopify_shop_url}/admin/api/2024-10/products/{product.shopify_product_id}.json",
                                headers={
                                    "Content-Type": "application/json",
                                    "X-Shopify-Access-Token": settings.shopify_access_token,
                                },
                                json={
                                    "product": {
                                        "id": int(product.shopify_product_id),
                                        "body_html": product.description or "",
                                        "tags": ", ".join(product.tags or []),
                                        "metafields": [
                                            {
                                                "namespace": "seo",
                                                "key": "title",
                                                "value": product.seo_title or "",
                                                "type": "single_line_text_field",
                                            },
                                            {
                                                "namespace": "seo",
                                                "key": "description",
                                                "value": product.seo_description or "",
                                                "type": "single_line_text_field",
                                            },
                                        ],
                                    }
                                },
                            )
                            if resp.status_code == 200:
                                synced_count += 1
                        except Exception:
                            pass

        await db.flush()

        await self.emit_event(project_id, "agent_progress", {
            "agent": self.agent_name, "step": "Copy complete!", "progress": 100,
        })

        return {
            "summary": f"Generated copy for {len(product_descriptions)} products, pages, emails, and social media.",
            "products_updated": updated_count,
            "products_synced_to_shopify": synced_count,
            "page_content": copy_data.get("page_content", {}),
            "email_templates": copy_data.get("email_templates", {}),
            "social_media": copy_data.get("social_media", {}),
            "product_descriptions_count": len(product_descriptions),
            "_tokens": tokens1,
            "_cost": cost1,
        }
