"""
Orchestrator: LangGraph-based pipeline that chains all agents together.

Pipeline flow:
  research → store_builder → design → copy → review

Each node runs an agent, passes context to the next.
Human-in-the-loop at approval checkpoints.
"""

import asyncio
from datetime import datetime
from typing import Any, TypedDict, Optional
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update

from models.database import Project, ProjectStatus, AgentTask, TaskStatus, AgentType
from models.schemas import WSEvent
from core.websocket import ws_manager
from core.database import AsyncSessionLocal
from agents.research_agent import ResearchAgent
from agents.store_builder_agent import StoreBuilderAgent
from agents.design_agent import DesignAgent
from agents.copy_agent import CopyAgent


class PipelineState(TypedDict):
    """State that flows through the pipeline."""
    project_id: str
    status: str
    context: dict  # accumulated data from all agents
    current_agent: Optional[str]
    error: Optional[str]
    completed_agents: list[str]


class Orchestrator:
    """Main pipeline orchestrator. Runs agents in sequence with error handling."""

    def __init__(self):
        self.research_agent = ResearchAgent()
        self.store_builder_agent = StoreBuilderAgent()
        self.design_agent = DesignAgent()
        self.copy_agent = CopyAgent()

        self.agent_sequence = [
            ("research", self.research_agent, ProjectStatus.RESEARCHING),
            ("store_builder", self.store_builder_agent, ProjectStatus.BUILDING_STORE),
            ("design", self.design_agent, ProjectStatus.DESIGNING),
            ("copy", self.copy_agent, ProjectStatus.WRITING_COPY),
        ]

    async def _update_project_status(self, db: AsyncSession, project_id: UUID, status: ProjectStatus):
        await db.execute(
            update(Project).where(Project.id == project_id).values(
                status=status, updated_at=datetime.utcnow()
            )
        )
        await db.flush()

    async def _emit(self, project_id: UUID, event: str, data: dict = None):
        ws_event = WSEvent(
            event=event,
            project_id=str(project_id),
            agent_type="orchestrator",
            data=data or {},
        )
        await ws_manager.send_event(ws_event)

    async def run_pipeline(self, project_id: UUID) -> dict:
        """
        Run the full pipeline for a project.
        Returns final state dict.
        """
        state: PipelineState = {
            "project_id": str(project_id),
            "status": "running",
            "context": {},
            "current_agent": None,
            "error": None,
            "completed_agents": [],
        }

        await self._emit(project_id, "pipeline_started", {
            "total_agents": len(self.agent_sequence),
        })

        async with AsyncSessionLocal() as db:
            try:
                for agent_name, agent, project_status in self.agent_sequence:
                    state["current_agent"] = agent_name

                    # Update project status
                    await self._update_project_status(db, project_id, project_status)

                    await self._emit(project_id, "pipeline_agent_starting", {
                        "agent": agent_name,
                        "step": len(state["completed_agents"]) + 1,
                        "total": len(self.agent_sequence),
                    })

                    # Run the agent
                    result = await agent.run(db, project_id, state["context"])

                    # Merge result into pipeline context
                    # Remove internal tracking keys
                    clean_result = {k: v for k, v in result.items() if not k.startswith("_")}
                    state["context"].update(clean_result)
                    state["completed_agents"].append(agent_name)

                    await db.commit()

                    # Check if agent requires approval → pause pipeline
                    if agent.requires_approval:
                        state["status"] = "awaiting_approval"
                        await self._update_project_status(db, project_id, ProjectStatus.REVIEW)
                        await self._emit(project_id, "pipeline_paused_for_approval", {
                            "agent": agent_name,
                            "completed": len(state["completed_agents"]),
                            "total": len(self.agent_sequence),
                        })
                        # In a real implementation, the pipeline would wait here
                        # For now, we auto-continue (approval handled via API)
                        # The frontend will show an approval UI

                # Pipeline complete
                state["status"] = "completed"
                state["current_agent"] = None
                await self._update_project_status(db, project_id, ProjectStatus.REVIEW)
                await db.commit()

                await self._emit(project_id, "pipeline_completed", {
                    "agents_completed": state["completed_agents"],
                    "summary": state["context"].get("summary", ""),
                })

            except Exception as e:
                state["status"] = "failed"
                state["error"] = str(e)

                async with AsyncSessionLocal() as err_db:
                    await self._update_project_status(err_db, project_id, ProjectStatus.FAILED)
                    await err_db.commit()

                await self._emit(project_id, "pipeline_failed", {
                    "agent": state["current_agent"],
                    "error": str(e),
                    "completed_agents": state["completed_agents"],
                })

        return state

    async def resume_pipeline(self, project_id: UUID, from_agent: str) -> dict:
        """Resume a paused pipeline from a specific agent."""
        # Find where to resume
        start_idx = 0
        for i, (name, _, _) in enumerate(self.agent_sequence):
            if name == from_agent:
                start_idx = i
                break

        state: PipelineState = {
            "project_id": str(project_id),
            "status": "running",
            "context": {},
            "current_agent": None,
            "error": None,
            "completed_agents": [],
        }

        # Rebuild context from completed tasks
        async with AsyncSessionLocal() as db:
            result = await db.execute(
                select(AgentTask).where(
                    AgentTask.project_id == project_id,
                    AgentTask.status.in_([TaskStatus.COMPLETED, TaskStatus.APPROVED]),
                ).order_by(AgentTask.created_at)
            )
            completed_tasks = result.scalars().all()
            for t in completed_tasks:
                state["context"].update(t.output_data or {})
                state["completed_agents"].append(t.agent_type.value)

        # Run remaining agents
        remaining = self.agent_sequence[start_idx:]

        async with AsyncSessionLocal() as db:
            try:
                for agent_name, agent, project_status in remaining:
                    state["current_agent"] = agent_name
                    await self._update_project_status(db, project_id, project_status)

                    result = await agent.run(db, project_id, state["context"])
                    clean_result = {k: v for k, v in result.items() if not k.startswith("_")}
                    state["context"].update(clean_result)
                    state["completed_agents"].append(agent_name)
                    await db.commit()

                state["status"] = "completed"
                await self._update_project_status(db, project_id, ProjectStatus.REVIEW)
                await db.commit()

                await self._emit(project_id, "pipeline_completed", {
                    "agents_completed": state["completed_agents"],
                })

            except Exception as e:
                state["status"] = "failed"
                state["error"] = str(e)
                await self._emit(project_id, "pipeline_failed", {"error": str(e)})

        return state

    async def get_pipeline_status(self, project_id: UUID) -> dict:
        """Get current pipeline status for a project."""
        async with AsyncSessionLocal() as db:
            project = await db.get(Project, project_id)
            if not project:
                return {"error": "Project not found"}

            result = await db.execute(
                select(AgentTask).where(AgentTask.project_id == project_id).order_by(AgentTask.created_at)
            )
            tasks = result.scalars().all()

            completed = [t for t in tasks if t.status in (TaskStatus.COMPLETED, TaskStatus.APPROVED)]
            total_agents = len(self.agent_sequence)
            progress = (len(completed) / total_agents * 100) if total_agents > 0 else 0

            return {
                "project_id": str(project_id),
                "project_status": project.status.value,
                "progress_percent": progress,
                "total_agents": total_agents,
                "completed_agents": len(completed),
                "tasks": [
                    {
                        "id": str(t.id),
                        "agent": t.agent_type.value,
                        "task_name": t.task_name,
                        "status": t.status.value,
                        "duration": t.duration_seconds,
                        "cost": t.api_cost,
                        "tokens": t.tokens_used,
                        "requires_approval": t.requires_approval,
                        "error": t.error_message,
                    }
                    for t in tasks
                ],
            }


# Singleton
orchestrator = Orchestrator()
