import json
from uuid import UUID

import httpx
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from agents.base_agent import BaseAgent
from config import get_settings
from models.database import (
    AgentType, AgentTask, Product, Project, TaskStatus,
)

settings = get_settings()


STORE_SYSTEM_PROMPT = """You are an expert Shopify store builder. Based on the research data provided, generate the optimal store configuration.

Return a JSON object with this structure:
{
    "store_config": {
        "store_name": "Catchy store name",
        "tagline": "Short tagline",
        "currency": "USD",
        "shipping_config": {
            "free_shipping_threshold": 50.00,
            "flat_rate": 5.99,
            "estimated_delivery_days": "5-7"
        },
        "collections": [
            {
                "title": "Collection Name",
                "description": "Collection description",
                "sort_order": "best-selling"
            }
        ],
        "pages": [
            {
                "title": "About Us",
                "content_summary": "Brief description of what content to put here"
            },
            {
                "title": "Shipping & Returns",
                "content_summary": "Policy description"
            }
        ],
        "navigation": {
            "main_menu": ["Home", "Shop", "Collections", "About"],
            "footer_menu": ["Shipping & Returns", "Contact", "Privacy Policy"]
        }
    },
    "product_configs": [
        {
            "product_name": "Name from research",
            "shopify_title": "SEO-optimized title for Shopify",
            "shopify_product_type": "Product type",
            "vendor": "Store name",
            "variants": [
                {
                    "option_name": "Size",
                    "values": ["S", "M", "L", "XL"]
                }
            ],
            "suggested_price": 29.99,
            "compare_at_price": 39.99
        }
    ]
}"""


class StoreBuilderAgent(BaseAgent):
    agent_type = AgentType.STORE_BUILDER
    agent_name = "Store Builder Agent"

    @property
    def requires_approval(self) -> bool:
        return True  # Store creation needs human approval

    def _shopify_headers(self) -> dict:
        return {
            "Content-Type": "application/json",
            "X-Shopify-Access-Token": settings.shopify_access_token,
        }

    @property
    def _shopify_base_url(self) -> str:
        return f"https://{settings.shopify_shop_url}/admin/api/2024-10"

    async def execute(
        self, db: AsyncSession, project_id: UUID, context: dict, task: AgentTask
    ) -> dict:
        project = await db.get(Project, project_id)

        # Get products from research phase
        result = await db.execute(
            select(Product).where(Product.project_id == project_id).order_by(Product.overall_score.desc())
        )
        products = result.scalars().all()

        # Step 1: Generate store config via Claude
        await self.emit_event(project_id, "agent_progress", {
            "agent": self.agent_name, "step": "Planning store structure...", "progress": 15,
        })

        products_info = [
            {
                "name": p.name,
                "description": p.description,
                "price": p.price,
                "cost": p.cost,
                "category": p.category,
                "tags": p.tags,
            }
            for p in products
        ]

        user_message = f"""Create a Shopify store configuration for:
Niche: {project.niche}
Store name idea: {project.name}
SEO keywords: {json.dumps(context.get('seo_keywords', []))}

Products from research:
{json.dumps(products_info, indent=2)}

Generate the optimal store structure, collections, and product configurations."""

        store_config, tokens, cost = await self.call_claude_json(
            STORE_SYSTEM_PROMPT, user_message, max_tokens=4096
        )

        # Step 2: Create products in Shopify
        await self.emit_event(project_id, "agent_progress", {
            "agent": self.agent_name, "step": "Creating products in Shopify...", "progress": 40,
        })

        created_products = []
        product_configs = store_config.get("product_configs", [])

        async with httpx.AsyncClient(timeout=30.0) as client:
            for i, prod_config in enumerate(product_configs):
                # Match with our DB product
                matching_product = None
                for p in products:
                    if p.name.lower() in prod_config.get("product_name", "").lower() or \
                       prod_config.get("product_name", "").lower() in p.name.lower():
                        matching_product = p
                        break

                if not matching_product and products:
                    matching_product = products[min(i, len(products) - 1)]

                # Build Shopify product payload
                variants = []
                for variant_config in prod_config.get("variants", []):
                    for value in variant_config.get("values", []):
                        variants.append({
                            "option1": value,
                            "price": str(prod_config.get("suggested_price", matching_product.price or 29.99)),
                            "compare_at_price": str(prod_config.get("compare_at_price", ""))
                            if prod_config.get("compare_at_price") else None,
                        })

                if not variants:
                    variants = [{
                        "price": str(prod_config.get("suggested_price", matching_product.price or 29.99)),
                    }]

                shopify_payload = {
                    "product": {
                        "title": prod_config.get("shopify_title", matching_product.name),
                        "body_html": matching_product.description or "",
                        "vendor": prod_config.get("vendor", project.name),
                        "product_type": prod_config.get("shopify_product_type", ""),
                        "tags": ", ".join(matching_product.tags or []),
                        "variants": variants,
                        "options": [
                            {"name": v.get("option_name", "Size"), "values": v.get("values", [])}
                            for v in prod_config.get("variants", [])
                        ] if prod_config.get("variants") else [],
                        "status": "draft",  # Don't publish yet
                    }
                }

                try:
                    resp = await client.post(
                        f"{self._shopify_base_url}/products.json",
                        headers=self._shopify_headers(),
                        json=shopify_payload,
                    )

                    if resp.status_code == 201:
                        shopify_data = resp.json().get("product", {})
                        if matching_product:
                            matching_product.shopify_product_id = str(shopify_data.get("id"))
                            matching_product.seo_title = prod_config.get("shopify_title")
                        created_products.append({
                            "name": prod_config.get("shopify_title"),
                            "shopify_id": shopify_data.get("id"),
                            "status": "draft",
                        })
                    else:
                        created_products.append({
                            "name": prod_config.get("shopify_title"),
                            "error": f"HTTP {resp.status_code}: {resp.text[:200]}",
                            "status": "failed",
                        })

                except Exception as e:
                    created_products.append({
                        "name": prod_config.get("shopify_title", "Unknown"),
                        "error": str(e),
                        "status": "failed",
                    })

                await self.emit_event(project_id, "agent_progress", {
                    "agent": self.agent_name,
                    "step": f"Created product {i+1}/{len(product_configs)}",
                    "progress": 40 + int(50 * (i + 1) / max(len(product_configs), 1)),
                })

            # Step 3: Create collections
            await self.emit_event(project_id, "agent_progress", {
                "agent": self.agent_name, "step": "Creating collections...", "progress": 92,
            })

            collections_created = []
            for coll in store_config.get("store_config", {}).get("collections", []):
                try:
                    resp = await client.post(
                        f"{self._shopify_base_url}/custom_collections.json",
                        headers=self._shopify_headers(),
                        json={
                            "custom_collection": {
                                "title": coll["title"],
                                "body_html": coll.get("description", ""),
                                "sort_order": coll.get("sort_order", "best-selling"),
                            }
                        },
                    )
                    if resp.status_code == 201:
                        collections_created.append(coll["title"])
                except Exception:
                    pass

        # Update project with store info
        project.shopify_store_url = f"https://{settings.shopify_shop_url}"
        await db.flush()

        await self.emit_event(project_id, "agent_progress", {
            "agent": self.agent_name, "step": "Store setup complete!", "progress": 100,
        })

        return {
            "summary": f"Store configured with {len(created_products)} products and {len(collections_created)} collections.",
            "store_config": store_config.get("store_config", {}),
            "products_created": created_products,
            "collections_created": collections_created,
            "store_url": f"https://{settings.shopify_shop_url}",
            "_tokens": tokens,
            "_cost": cost,
        }
