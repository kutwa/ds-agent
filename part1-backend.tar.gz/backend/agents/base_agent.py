import time
import traceback
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any, Optional
from uuid import UUID

import anthropic
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from config import get_settings
from models.database import AgentTask, AgentType, TaskStatus, Project, ProjectStatus
from models.schemas import WSEvent
from core.websocket import ws_manager

settings = get_settings()


class BaseAgent(ABC):
    """Base class for all agents in the system."""

    agent_type: AgentType
    agent_name: str

    def __init__(self):
        self.client = anthropic.AsyncAnthropic(api_key=settings.anthropic_api_key)
        self.model = settings.anthropic_model

    async def call_claude(
        self,
        system_prompt: str,
        user_message: str,
        max_tokens: int = 4096,
        temperature: float = 0.7,
    ) -> tuple[str, int, float]:
        """Call Claude API and return (response_text, tokens_used, cost)."""
        response = await self.client.messages.create(
            model=self.model,
            max_tokens=max_tokens,
            temperature=temperature,
            system=system_prompt,
            messages=[{"role": "user", "content": user_message}],
        )

        text = response.content[0].text
        input_tokens = response.usage.input_tokens
        output_tokens = response.usage.output_tokens
        total_tokens = input_tokens + output_tokens

        # Approximate cost (Claude Sonnet pricing)
        cost = (input_tokens * 3.0 / 1_000_000) + (output_tokens * 15.0 / 1_000_000)

        return text, total_tokens, cost

    async def call_claude_json(
        self,
        system_prompt: str,
        user_message: str,
        max_tokens: int = 4096,
        temperature: float = 0.5,
    ) -> tuple[dict, int, float]:
        """Call Claude and parse JSON response."""
        import json

        full_system = (
            system_prompt
            + "\n\nIMPORTANT: Respond ONLY with valid JSON. No markdown, no backticks, no explanation."
        )

        text, tokens, cost = await self.call_claude(full_system, user_message, max_tokens, temperature)

        # Clean potential markdown fences
        cleaned = text.strip()
        if cleaned.startswith("```"):
            cleaned = cleaned.split("\n", 1)[-1]
        if cleaned.endswith("```"):
            cleaned = cleaned.rsplit("```", 1)[0]
        cleaned = cleaned.strip()

        try:
            data = json.loads(cleaned)
        except json.JSONDecodeError:
            # Try to extract JSON from response
            start = cleaned.find("{")
            end = cleaned.rfind("}") + 1
            if start >= 0 and end > start:
                data = json.loads(cleaned[start:end])
            else:
                raise ValueError(f"Could not parse JSON from Claude response: {cleaned[:200]}")

        return data, tokens, cost

    async def create_task(
        self,
        db: AsyncSession,
        project_id: UUID,
        task_name: str,
        input_data: dict = None,
        requires_approval: bool = False,
    ) -> AgentTask:
        """Create a task record in the database."""
        task = AgentTask(
            project_id=project_id,
            agent_type=self.agent_type,
            task_name=task_name,
            status=TaskStatus.PENDING,
            input_data=input_data or {},
            requires_approval=requires_approval,
        )
        db.add(task)
        await db.flush()
        return task

    async def update_task(
        self,
        db: AsyncSession,
        task: AgentTask,
        status: TaskStatus,
        output_data: dict = None,
        error_message: str = None,
        tokens_used: int = 0,
        api_cost: float = 0.0,
    ):
        """Update task status and data."""
        task.status = status
        if output_data:
            task.output_data = output_data
        if error_message:
            task.error_message = error_message
        task.tokens_used = (task.tokens_used or 0) + tokens_used
        task.api_cost = (task.api_cost or 0) + api_cost

        if status == TaskStatus.RUNNING and not task.started_at:
            task.started_at = datetime.utcnow()
        if status in (TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.AWAITING_APPROVAL):
            task.completed_at = datetime.utcnow()
            if task.started_at:
                task.duration_seconds = (task.completed_at - task.started_at).total_seconds()

        await db.flush()

    async def emit_event(self, project_id: UUID, event: str, data: dict = None):
        """Send a WebSocket event."""
        ws_event = WSEvent(
            event=event,
            project_id=str(project_id),
            agent_type=self.agent_type.value,
            data=data or {},
        )
        await ws_manager.send_event(ws_event)

    async def run(self, db: AsyncSession, project_id: UUID, context: dict = None) -> dict:
        """
        Main entry point. Creates task, runs execute(), handles errors.
        Returns output dict that gets passed to the next agent.
        """
        context = context or {}
        task = await self.create_task(
            db, project_id, f"{self.agent_name} - Main Task", input_data=context,
            requires_approval=self.requires_approval,
        )

        await self.emit_event(project_id, "agent_started", {
            "agent": self.agent_name,
            "task_id": str(task.id),
        })

        try:
            await self.update_task(db, task, TaskStatus.RUNNING)

            result = await self.execute(db, project_id, context, task)

            final_status = (
                TaskStatus.AWAITING_APPROVAL if self.requires_approval
                else TaskStatus.COMPLETED
            )
            await self.update_task(
                db, task, final_status,
                output_data=result,
                tokens_used=result.get("_tokens", 0),
                api_cost=result.get("_cost", 0.0),
            )

            await self.emit_event(project_id, "agent_completed", {
                "agent": self.agent_name,
                "task_id": str(task.id),
                "summary": result.get("summary", ""),
            })

            return result

        except Exception as e:
            error_msg = f"{type(e).__name__}: {str(e)}\n{traceback.format_exc()}"
            await self.update_task(db, task, TaskStatus.FAILED, error_message=error_msg)

            await self.emit_event(project_id, "agent_failed", {
                "agent": self.agent_name,
                "task_id": str(task.id),
                "error": str(e),
            })

            raise

    @property
    def requires_approval(self) -> bool:
        """Override in subclass to require human approval."""
        return False

    @abstractmethod
    async def execute(
        self, db: AsyncSession, project_id: UUID, context: dict, task: AgentTask
    ) -> dict:
        """
        Implement the agent's main logic.
        Returns a dict with results that gets passed to next agent.
        """
        ...
