# 🤖 Multi-Agent E-Commerce System

Zautomatyzowany pipeline od researchu produktowego po gotowy sklep Shopify — napędzany przez sieć agentów AI (Claude API).

## Architektura

```
┌─────────────────────────────────────────────────┐
│                  DASHBOARD (React)               │
│  Projects · Pipeline View · Approval · Logs      │
└──────────────────────┬──────────────────────────┘
                       │ REST API + WebSocket
┌──────────────────────┴──────────────────────────┐
│               FastAPI Backend                    │
│                                                  │
│  ┌─────────────────────────────────────────┐     │
│  │         ORCHESTRATOR (LangGraph)        │     │
│  │                                         │     │
│  │  ┌──────────┐  ┌──────────────────┐     │     │
│  │  │ Research  │→ │  Store Builder   │     │     │
│  │  │  Agent   │  │     Agent        │     │     │
│  │  └──────────┘  └───────┬──────────┘     │     │
│  │                        ↓                │     │
│  │  ┌──────────┐  ┌──────────────────┐     │     │
│  │  │   Copy   │← │  Design Agent    │     │     │
│  │  │  Agent   │  │                  │     │     │
│  │  └──────────┘  └──────────────────┘     │     │
│  └─────────────────────────────────────────┘     │
│                                                  │
│  PostgreSQL · Redis · S3/MinIO                   │
└──────────────────────────────────────────────────┘
```

## Agenci

| Agent | Funkcja | Wymaga zatwierdzenia? |
|-------|---------|----------------------|
| **Research Agent** | Analiza niszy, trending produkty, konkurencja, scoring | ❌ |
| **Store Builder Agent** | Konfiguracja Shopify, tworzenie produktów i kolekcji | ✅ |
| **Design Agent** | Brand identity, kolory, fonty, theme CSS, grafiki AI | ✅ |
| **Copy Agent** | Opisy produktów, SEO, treści stron, emaile, social media | ✅ |

## Wymagania

- **Docker** + **Docker Compose** (zalecane)
- LUB: Python 3.12+, Node.js 20+, PostgreSQL 16+, Redis 7+
- Klucze API (patrz konfiguracja)

---

## Szybki start z Docker

### 1. Sklonuj projekt

```bash
cd multi-agent-ecommerce
```

### 2. Skonfiguruj zmienne środowiskowe

```bash
cp .env.example .env
```

Edytuj `.env` i uzupełnij klucze API:

```env
# WYMAGANE
ANTHROPIC_API_KEY=sk-ant-...        # Z https://console.anthropic.com/
SHOPIFY_API_KEY=...                  # Z Shopify Partners
SHOPIFY_API_SECRET=...
SHOPIFY_ACCESS_TOKEN=shpat_...
SHOPIFY_SHOP_URL=twoj-sklep.myshopify.com

# OPCJONALNE (do generowania grafik)
OPENAI_API_KEY=sk-...                # Z https://platform.openai.com/
```

### 3. Uruchom

```bash
docker compose up -d
```

### 4. Otwórz dashboard

```
http://localhost:5173
```

API docs (Swagger):
```
http://localhost:8000/docs
```

---

## Ręczna instalacja (bez Dockera)

### Backend

```bash
cd backend
python -m venv venv
source venv/bin/activate  # Linux/Mac
# venv\Scripts\activate   # Windows

pip install -r requirements.txt

# Utwórz bazę danych
# Upewnij się, że PostgreSQL działa i baza 'agent_ecommerce' istnieje
createdb agent_ecommerce

# Inicjalizuj tabele
python init_db.py

# Uruchom serwer
uvicorn main:app --reload --port 8000
```

### Frontend

```bash
cd frontend
npm install
npm run dev
```

---

## Jak korzystać

### 1. Utwórz projekt

- Kliknij **"New Project"** na dashboardzie
- Podaj nazwę i **niszę** (im bardziej szczegółowa, tym lepiej)
  - ✅ Dobrze: *"Eco-friendly dog toys for urban millennials aged 25-35"*
  - ❌ Źle: *"Dog toys"*

### 2. Uruchom pipeline

- Wejdź w projekt → zakładka **Pipeline**
- Kliknij **"Start Pipeline"**
- Obserwuj live progress każdego agenta

### 3. Zatwierdzaj wyniki

Agenci **Store Builder**, **Design** i **Copy** wymagają zatwierdzenia:

- Zakładka **Approval Queue** → przejrzyj wyniki → **Approve** / **Reject**
- Po zatwierdzeniu pipeline kontynuuje do następnego agenta

### 4. Sprawdź produkty

- Zakładka **Products** → lista znalezionych produktów ze scoringiem
- Każdy produkt ma: trend score, competition score, margin score

### 5. Gotowy sklep

Po zakończeniu pipeline'u Twój sklep Shopify jest skonfigurowany z:
- Produktami (draft — do ręcznej publikacji)
- Kolekcjami
- Brand identity (kolory, fonty)
- Opisami SEO
- Treściami stron

---

## Konfiguracja Shopify

### Uzyskanie kluczy API:

1. Idź do [Shopify Partners](https://partners.shopify.com/)
2. Utwórz **Development store**
3. Utwórz **Custom app** w ustawieniach sklepu:
   - Settings → Apps and sales channels → Develop apps
   - Create an app → Configure Admin API scopes
4. Wymagane scopes:
   ```
   write_products, read_products
   write_themes, read_themes
   write_content, read_content
   write_custom_collection, read_custom_collection
   ```
5. Install app → skopiuj **Access token**

---

## Struktura projektu

```
multi-agent-ecommerce/
├── .env.example              # Szablon zmiennych środowiskowych
├── .env                      # Twoja konfiguracja (nie commituj!)
├── docker-compose.yml        # Pełny stack w Dockerze
├── setup.sh                  # Skrypt instalacyjny
│
├── backend/
│   ├── Dockerfile
│   ├── requirements.txt
│   ├── main.py               # FastAPI entry point
│   ├── init_db.py            # Inicjalizacja bazy
│   │
│   ├── agents/
│   │   ├── base_agent.py     # Klasa bazowa agenta
│   │   ├── research_agent.py # Research & product discovery
│   │   ├── store_builder_agent.py  # Shopify setup
│   │   ├── design_agent.py   # Brand & visual design
│   │   ├── copy_agent.py     # SEO content & copy
│   │   └── orchestrator.py   # LangGraph pipeline
│   │
│   ├── api/
│   │   ├── projects.py       # CRUD endpoints
│   │   └── pipeline.py       # Pipeline control endpoints
│   │
│   ├── core/
│   │   ├── database.py       # PostgreSQL async connection
│   │   └── websocket.py      # WebSocket manager
│   │
│   ├── models/
│   │   ├── database.py       # SQLAlchemy models
│   │   └── schemas.py        # Pydantic schemas
│   │
│   ├── config/
│   │   └── settings.py       # Pydantic settings
│   │
│   └── services/             # Business logic (extensible)
│
└── frontend/
    ├── Dockerfile
    ├── package.json
    ├── vite.config.js
    ├── tailwind.config.js
    │
    └── src/
        ├── App.jsx           # Router & layout
        ├── main.jsx          # Entry point
        │
        ├── pages/
        │   ├── DashboardPage.jsx
        │   ├── ProjectsPage.jsx
        │   ├── ProjectDetailPage.jsx
        │   ├── NewProjectPage.jsx
        │   ├── PipelinePage.jsx
        │   ├── LogsPage.jsx
        │   └── SettingsPage.jsx
        │
        ├── components/
        │   ├── common/       # Sidebar, StatusBadge
        │   ├── dashboard/    # StatCard
        │   ├── pipeline/     # AgentCard, PipelineView, ApprovalQueue
        │   └── projects/     # ProjectList, CreateProjectForm
        │
        ├── hooks/
        │   ├── useWebSocket.js   # Real-time WebSocket
        │   └── useAsync.js       # Data fetching
        │
        ├── services/
        │   └── api.js        # REST API client
        │
        └── styles/
            └── globals.css   # Tailwind + custom styles
```

---

## API Endpoints

### Projects
| Method | Endpoint | Opis |
|--------|----------|------|
| GET | `/api/projects` | Lista projektów |
| POST | `/api/projects` | Utwórz projekt |
| GET | `/api/projects/{id}` | Szczegóły projektu |
| PATCH | `/api/projects/{id}` | Aktualizuj projekt |
| DELETE | `/api/projects/{id}` | Usuń projekt |
| GET | `/api/projects/{id}/products` | Produkty projektu |
| GET | `/api/projects/{id}/tasks` | Zadania agentów |

### Pipeline
| Method | Endpoint | Opis |
|--------|----------|------|
| POST | `/api/pipeline/start` | Uruchom pipeline |
| GET | `/api/pipeline/status/{id}` | Status pipeline |
| POST | `/api/pipeline/resume/{id}` | Wznów pipeline |
| POST | `/api/pipeline/approve/{task_id}` | Zatwierdź/odrzuć task |
| POST | `/api/pipeline/stop/{id}` | Zatrzymaj pipeline |

### WebSocket
| Endpoint | Opis |
|----------|------|
| `ws://localhost:8000/ws` | Globalne eventy |
| `ws://localhost:8000/ws/{project_id}` | Eventy projektu |

---

## Rozszerzanie systemu

### Dodanie nowego agenta

1. Utwórz plik w `backend/agents/new_agent.py`
2. Rozszerz `BaseAgent`:

```python
from agents.base_agent import BaseAgent
from models.database import AgentType

class NewAgent(BaseAgent):
    agent_type = AgentType.NEW_TYPE  # Dodaj w enum
    agent_name = "New Agent"

    async def execute(self, db, project_id, context, task):
        result, tokens, cost = await self.call_claude_json(
            system_prompt="...",
            user_message="..."
        )
        return {"summary": "Done", "_tokens": tokens, "_cost": cost}
```

3. Dodaj do `orchestrator.py` w `agent_sequence`
4. Dodaj `AgentType` w `models/database.py`

---

## Rozwiązywanie problemów

### Backend nie startuje
```bash
# Sprawdź logi
docker compose logs backend

# Sprawdź bazę
docker compose exec postgres psql -U postgres -d agent_ecommerce -c "\dt"
```

### Frontend nie łączy się z API
- Sprawdź czy backend działa: `curl http://localhost:8000/health`
- Sprawdź proxy w `vite.config.js`

### Shopify API errors
- Sprawdź czy access token jest aktualny
- Sprawdź scopes aplikacji
- Sprawdź limity API (2 requests/second dla REST)

### Agent failure
- Sprawdź zakładkę **Tasks** → kliknij na failed task → error message
- Sprawdź logi: `docker compose logs backend -f`
- Najczęściej: brak/zły API key lub timeout

---

## Licencja

MIT — rób z tym co chcesz.
