import uuid
from datetime import datetime
from sqlalchemy import (
    Column, String, Text, Float, Integer, Boolean, DateTime,
    ForeignKey, JSON, Enum as SAEnum
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import DeclarativeBase, relationship
import enum


class Base(DeclarativeBase):
    pass


# ──────────────────────────────────────────────
# Enums
# ──────────────────────────────────────────────

class ProjectStatus(str, enum.Enum):
    DRAFT = "draft"
    RESEARCHING = "researching"
    BUILDING_STORE = "building_store"
    DESIGNING = "designing"
    WRITING_COPY = "writing_copy"
    REVIEW = "review"
    LIVE = "live"
    PAUSED = "paused"
    FAILED = "failed"


class AgentType(str, enum.Enum):
    ORCHESTRATOR = "orchestrator"
    RESEARCH = "research"
    STORE_BUILDER = "store_builder"
    DESIGN = "design"
    COPY = "copy"


class TaskStatus(str, enum.Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    AWAITING_APPROVAL = "awaiting_approval"
    APPROVED = "approved"
    REJECTED = "rejected"


# ──────────────────────────────────────────────
# Models
# ──────────────────────────────────────────────

class Project(Base):
    __tablename__ = "projects"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(255), nullable=False)
    niche = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    status = Column(SAEnum(ProjectStatus), default=ProjectStatus.DRAFT)
    config = Column(JSON, default=dict)  # extra settings per project

    # Shopify
    shopify_store_url = Column(String(500), nullable=True)
    shopify_store_id = Column(String(255), nullable=True)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relations
    products = relationship("Product", back_populates="project", cascade="all, delete-orphan")
    tasks = relationship("AgentTask", back_populates="project", cascade="all, delete-orphan")
    research_reports = relationship("ResearchReport", back_populates="project", cascade="all, delete-orphan")


class Product(Base):
    __tablename__ = "products"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    project_id = Column(UUID(as_uuid=True), ForeignKey("projects.id"), nullable=False)

    # Product info
    name = Column(String(500), nullable=False)
    description = Column(Text, nullable=True)
    seo_title = Column(String(255), nullable=True)
    seo_description = Column(Text, nullable=True)
    price = Column(Float, nullable=True)
    cost = Column(Float, nullable=True)
    category = Column(String(255), nullable=True)
    tags = Column(JSON, default=list)
    images = Column(JSON, default=list)  # list of image URLs
    variants = Column(JSON, default=list)

    # Shopify sync
    shopify_product_id = Column(String(255), nullable=True)
    is_published = Column(Boolean, default=False)

    # Scoring from research
    trend_score = Column(Float, nullable=True)
    competition_score = Column(Float, nullable=True)
    margin_score = Column(Float, nullable=True)
    overall_score = Column(Float, nullable=True)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relations
    project = relationship("Project", back_populates="products")


class ResearchReport(Base):
    __tablename__ = "research_reports"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    project_id = Column(UUID(as_uuid=True), ForeignKey("projects.id"), nullable=False)

    niche_analysis = Column(JSON, default=dict)
    competitors = Column(JSON, default=list)
    trending_products = Column(JSON, default=list)
    market_data = Column(JSON, default=dict)
    recommendations = Column(Text, nullable=True)
    raw_data = Column(JSON, default=dict)

    created_at = Column(DateTime, default=datetime.utcnow)

    project = relationship("Project", back_populates="research_reports")


class AgentTask(Base):
    __tablename__ = "agent_tasks"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    project_id = Column(UUID(as_uuid=True), ForeignKey("projects.id"), nullable=False)

    agent_type = Column(SAEnum(AgentType), nullable=False)
    task_name = Column(String(255), nullable=False)
    status = Column(SAEnum(TaskStatus), default=TaskStatus.PENDING)

    # Input/output
    input_data = Column(JSON, default=dict)
    output_data = Column(JSON, default=dict)
    error_message = Column(Text, nullable=True)

    # Metrics
    started_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)
    duration_seconds = Column(Float, nullable=True)
    api_cost = Column(Float, default=0.0)
    tokens_used = Column(Integer, default=0)

    # Approval
    requires_approval = Column(Boolean, default=False)
    approved_by = Column(String(255), nullable=True)
    approved_at = Column(DateTime, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)

    project = relationship("Project", back_populates="tasks")
