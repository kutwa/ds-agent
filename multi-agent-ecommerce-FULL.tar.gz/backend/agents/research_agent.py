import json
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from agents.base_agent import BaseAgent
from models.database import (
    AgentType, AgentTask, Product, ResearchReport, Project, TaskStatus,
)

RESEARCH_SYSTEM_PROMPT = """You are an expert e-commerce market research analyst. Your job is to analyze a given niche and identify the best products to sell online.

You must return your analysis as a JSON object with this exact structure:
{
    "niche_analysis": {
        "overview": "Brief overview of the niche",
        "market_size": "Estimated market size or description",
        "growth_trend": "growing/stable/declining",
        "target_audience": "Description of target customers",
        "key_insights": ["insight1", "insight2", "insight3"]
    },
    "competitors": [
        {
            "name": "Competitor name",
            "url": "URL if known",
            "strengths": ["strength1", "strength2"],
            "weaknesses": ["weakness1", "weakness2"],
            "price_range": "Low/Medium/High"
        }
    ],
    "trending_products": [
        {
            "name": "Product name",
            "description": "Brief description",
            "estimated_price": 29.99,
            "estimated_cost": 10.00,
            "estimated_margin_percent": 66.7,
            "trend_score": 8.5,
            "competition_level": "low/medium/high",
            "competition_score": 7.0,
            "margin_score": 8.0,
            "overall_score": 7.8,
            "tags": ["tag1", "tag2"],
            "category": "Category name",
            "why_recommended": "Reason this product is a good pick"
        }
    ],
    "market_data": {
        "average_price_range": "$X - $Y",
        "best_selling_season": "Season or 'year-round'",
        "top_marketing_channels": ["channel1", "channel2"],
        "seo_keywords": ["keyword1", "keyword2", "keyword3"]
    },
    "recommendations": "Your overall strategic recommendation in 2-3 paragraphs"
}

Find 5-10 trending products. Score each from 1-10 for trend, competition, margin, and overall.
Be specific and actionable. Base your analysis on real market knowledge."""


class ResearchAgent(BaseAgent):
    agent_type = AgentType.RESEARCH
    agent_name = "Research Agent"

    async def execute(
        self, db: AsyncSession, project_id: UUID, context: dict, task: AgentTask
    ) -> dict:
        # Get project
        project = await db.get(Project, project_id)
        niche = project.niche

        # Step 1: Main research analysis
        await self.emit_event(project_id, "agent_progress", {
            "agent": self.agent_name, "step": "Analyzing niche and market...", "progress": 20,
        })

        user_message = f"""Analyze this e-commerce niche thoroughly: "{niche}"

Additional context from project:
- Project name: {project.name}
- Description: {project.description or 'None provided'}
- Extra config: {json.dumps(project.config)}

Provide a comprehensive market analysis with product recommendations."""

        research_data, tokens1, cost1 = await self.call_claude_json(
            RESEARCH_SYSTEM_PROMPT, user_message, max_tokens=4096, temperature=0.7
        )

        await self.emit_event(project_id, "agent_progress", {
            "agent": self.agent_name, "step": "Processing research data...", "progress": 60,
        })

        # Step 2: Save research report
        report = ResearchReport(
            project_id=project_id,
            niche_analysis=research_data.get("niche_analysis", {}),
            competitors=research_data.get("competitors", []),
            trending_products=research_data.get("trending_products", []),
            market_data=research_data.get("market_data", {}),
            recommendations=research_data.get("recommendations", ""),
            raw_data=research_data,
        )
        db.add(report)

        # Step 3: Create product records from top recommendations
        products_created = []
        for prod_data in research_data.get("trending_products", [])[:5]:  # top 5
            product = Product(
                project_id=project_id,
                name=prod_data.get("name", "Unknown"),
                description=prod_data.get("description", ""),
                price=prod_data.get("estimated_price"),
                cost=prod_data.get("estimated_cost"),
                category=prod_data.get("category", ""),
                tags=prod_data.get("tags", []),
                trend_score=prod_data.get("trend_score"),
                competition_score=prod_data.get("competition_score"),
                margin_score=prod_data.get("margin_score"),
                overall_score=prod_data.get("overall_score"),
            )
            db.add(product)
            products_created.append(prod_data.get("name", "Unknown"))

        await db.flush()

        await self.emit_event(project_id, "agent_progress", {
            "agent": self.agent_name, "step": "Research complete!", "progress": 100,
        })

        total_tokens = tokens1
        total_cost = cost1

        return {
            "summary": f"Research completed for niche '{niche}'. Found {len(products_created)} products.",
            "products_found": len(products_created),
            "product_names": products_created,
            "report_id": str(report.id),
            "niche": niche,
            "market_data": research_data.get("market_data", {}),
            "seo_keywords": research_data.get("market_data", {}).get("seo_keywords", []),
            "_tokens": total_tokens,
            "_cost": total_cost,
        }
