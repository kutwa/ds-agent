from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func

from core.database import get_db
from models.database import Project, Product, AgentTask, ProjectStatus
from models.schemas import (
    ProjectCreate, ProjectUpdate, ProjectResponse,
    ProjectListResponse, ProductResponse, TaskResponse,
)

router = APIRouter(prefix="/projects", tags=["projects"])


@router.get("", response_model=ProjectListResponse)
async def list_projects(
    skip: int = 0,
    limit: int = 20,
    status: ProjectStatus | None = None,
    db: AsyncSession = Depends(get_db),
):
    query = select(Project).order_by(Project.created_at.desc())
    if status:
        query = query.where(Project.status == status)

    total_query = select(func.count(Project.id))
    if status:
        total_query = total_query.where(Project.status == status)

    result = await db.execute(query.offset(skip).limit(limit))
    total_result = await db.execute(total_query)

    projects = result.scalars().all()
    total = total_result.scalar()

    return ProjectListResponse(
        projects=[ProjectResponse.model_validate(p) for p in projects],
        total=total,
    )


@router.post("", response_model=ProjectResponse, status_code=201)
async def create_project(data: ProjectCreate, db: AsyncSession = Depends(get_db)):
    project = Project(
        name=data.name,
        niche=data.niche,
        description=data.description,
        config=data.config,
    )
    db.add(project)
    await db.flush()
    await db.refresh(project)
    return ProjectResponse.model_validate(project)


@router.get("/{project_id}", response_model=ProjectResponse)
async def get_project(project_id: UUID, db: AsyncSession = Depends(get_db)):
    project = await db.get(Project, project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    return ProjectResponse.model_validate(project)


@router.patch("/{project_id}", response_model=ProjectResponse)
async def update_project(
    project_id: UUID, data: ProjectUpdate, db: AsyncSession = Depends(get_db)
):
    project = await db.get(Project, project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    update_data = data.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(project, key, value)

    await db.flush()
    await db.refresh(project)
    return ProjectResponse.model_validate(project)


@router.delete("/{project_id}", status_code=204)
async def delete_project(project_id: UUID, db: AsyncSession = Depends(get_db)):
    project = await db.get(Project, project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    await db.delete(project)


@router.get("/{project_id}/products", response_model=list[ProductResponse])
async def get_project_products(project_id: UUID, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(Product)
        .where(Product.project_id == project_id)
        .order_by(Product.overall_score.desc().nullslast())
    )
    return [ProductResponse.model_validate(p) for p in result.scalars().all()]


@router.get("/{project_id}/tasks", response_model=list[TaskResponse])
async def get_project_tasks(project_id: UUID, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(AgentTask)
        .where(AgentTask.project_id == project_id)
        .order_by(AgentTask.created_at.desc())
    )
    return [TaskResponse.model_validate(t) for t in result.scalars().all()]
