"""
Database initialization script.
Run this to create all tables without Alembic.

Usage: python init_db.py
"""
import asyncio
import sys
sys.path.insert(0, ".")

from core.database import async_engine
from models.database import Base


async def create_tables():
    print("Creating database tables...")
    async with async_engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    print("✅ Tables created successfully!")
    await async_engine.dispose()


if __name__ == "__main__":
    asyncio.run(create_tables())
