#!/usr/bin/env python3
"""
Quick test script to verify the API is working.
Run: python test_api.py
"""
import httpx
import json
import sys

BASE = "http://localhost:8000"
CYAN = "\033[96m"
GREEN = "\033[92m"
RED = "\033[91m"
BOLD = "\033[1m"
NC = "\033[0m"


def test(name, method, path, body=None, expect_status=None):
    print(f"\n{CYAN}{BOLD}▸ {name}{NC}")
    try:
        with httpx.Client(base_url=BASE, timeout=10) as client:
            if method == "GET":
                r = client.get(path)
            elif method == "POST":
                r = client.post(path, json=body)
            elif method == "PATCH":
                r = client.patch(path, json=body)
            elif method == "DELETE":
                r = client.delete(path)

            if expect_status and r.status_code != expect_status:
                print(f"  {RED}✗ Expected {expect_status}, got {r.status_code}{NC}")
                return None

            print(f"  {GREEN}✓ {r.status_code}{NC}")
            if r.status_code != 204:
                data = r.json()
                print(f"  {json.dumps(data, indent=2, default=str)[:500]}")
                return data
            return None
    except Exception as e:
        print(f"  {RED}✗ Error: {e}{NC}")
        return None


def main():
    print(f"\n{BOLD}{'='*50}")
    print(f" Multi-Agent E-Commerce — API Test")
    print(f"{'='*50}{NC}")

    # 1. Health check
    health = test("Health Check", "GET", "/health", expect_status=200)
    if not health:
        print(f"\n{RED}Backend is not running! Start it first.{NC}")
        sys.exit(1)

    # 2. Create project
    project = test("Create Project", "POST", "/api/projects", body={
        "name": "Test Store — Eco Yoga Mats",
        "niche": "Premium eco-friendly yoga mats for beginners",
        "description": "Target audience: women 25-40, price range $30-80, focus on sustainability"
    }, expect_status=201)

    if not project:
        print(f"\n{RED}Failed to create project{NC}")
        sys.exit(1)

    project_id = project["id"]
    print(f"\n  Project ID: {project_id}")

    # 3. List projects
    test("List Projects", "GET", "/api/projects")

    # 4. Get project detail
    test("Get Project", "GET", f"/api/projects/{project_id}")

    # 5. Get products (empty)
    test("Get Products", "GET", f"/api/projects/{project_id}/products")

    # 6. Get tasks (empty)
    test("Get Tasks", "GET", f"/api/projects/{project_id}/tasks")

    # 7. Pipeline status
    test("Pipeline Status", "GET", f"/api/pipeline/status/{project_id}")

    # 8. Start pipeline (this will run agents!)
    print(f"\n{CYAN}{BOLD}▸ Start Pipeline{NC}")
    print(f"  ⚠  This will call the Claude API and Shopify API!")
    resp = input("  Run? (y/N): ")
    if resp.lower() == 'y':
        test("Start Pipeline", "POST", "/api/pipeline/start", body={
            "project_id": project_id
        })
        print(f"\n  Pipeline started! Open http://localhost:5173/projects/{project_id}")
        print(f"  to watch live progress.")
    else:
        print(f"  Skipped.")

    # 9. Cleanup option
    print(f"\n{CYAN}{BOLD}▸ Cleanup{NC}")
    resp = input("  Delete test project? (y/N): ")
    if resp.lower() == 'y':
        test("Delete Project", "DELETE", f"/api/projects/{project_id}", expect_status=204)

    print(f"\n{GREEN}{BOLD}All tests passed! ✓{NC}\n")


if __name__ == "__main__":
    main()
