import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  ArrowLeft, ExternalLink, Package, Clock, DollarSign, Hash
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import StatusBadge from '../components/common/StatusBadge';
import PipelineView from '../components/pipeline/PipelineView';
import ApprovalQueue from '../components/pipeline/ApprovalQueue';
import { projectsApi } from '../services/api';

export default function ProjectDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [project, setProject] = useState(null);
  const [products, setProducts] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('pipeline');

  const fetchAll = async () => {
    try {
      const [proj, prods, tks] = await Promise.all([
        projectsApi.get(id),
        projectsApi.getProducts(id),
        projectsApi.getTasks(id),
      ]);
      setProject(proj);
      setProducts(prods || []);
      setTasks(tks || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAll();
    const interval = setInterval(fetchAll, 10000);
    return () => clearInterval(interval);
  }, [id]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin w-6 h-6 border-2 border-accent-blue border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!project) {
    return (
      <div className="text-center py-20">
        <p className="text-white/30">Project not found</p>
      </div>
    );
  }

  const tabs = [
    { id: 'pipeline', label: 'Pipeline' },
    { id: 'products', label: `Products (${products.length})` },
    { id: 'tasks', label: `Tasks (${tasks.length})` },
    { id: 'approval', label: 'Approval Queue' },
  ];

  const totalCost = tasks.reduce((sum, t) => sum + (t.api_cost || 0), 0);
  const totalTokens = tasks.reduce((sum, t) => sum + (t.tokens_used || 0), 0);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Back */}
      <button
        onClick={() => navigate('/projects')}
        className="flex items-center gap-2 text-sm text-white/40 hover:text-white/70 transition-colors"
      >
        <ArrowLeft size={16} />
        Back to Projects
      </button>

      {/* Project Header */}
      <div className="card">
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <h1 className="text-xl font-bold">{project.name}</h1>
              <StatusBadge status={project.status} />
            </div>
            <p className="text-sm text-white/40 mb-1">
              Niche: <span className="text-white/60">{project.niche}</span>
            </p>
            {project.description && (
              <p className="text-xs text-white/30 max-w-2xl">{project.description}</p>
            )}
            <p className="text-xs text-white/20 mt-2 font-mono">
              Created {formatDistanceToNow(new Date(project.created_at), { addSuffix: true })}
            </p>
          </div>

          {project.shopify_store_url && (
            <a
              href={project.shopify_store_url}
              target="_blank"
              rel="noopener"
              className="btn-secondary flex items-center gap-2 text-xs"
            >
              <ExternalLink size={14} />
              Open Store
            </a>
          )}
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-5 pt-5 border-t border-border">
          <div className="flex items-center gap-2">
            <Package size={14} className="text-white/30" />
            <span className="text-xs text-white/40">Products:</span>
            <span className="text-xs font-semibold">{products.length}</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock size={14} className="text-white/30" />
            <span className="text-xs text-white/40">Tasks:</span>
            <span className="text-xs font-semibold">{tasks.length}</span>
          </div>
          <div className="flex items-center gap-2">
            <Hash size={14} className="text-white/30" />
            <span className="text-xs text-white/40">Tokens:</span>
            <span className="text-xs font-semibold font-mono">{totalTokens.toLocaleString()}</span>
          </div>
          <div className="flex items-center gap-2">
            <DollarSign size={14} className="text-white/30" />
            <span className="text-xs text-white/40">API Cost:</span>
            <span className="text-xs font-semibold font-mono">${totalCost.toFixed(4)}</span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-border pb-px">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2.5 text-sm font-medium transition-all border-b-2 ${
              activeTab === tab.id
                ? 'text-accent-blue border-accent-blue'
                : 'text-white/40 border-transparent hover:text-white/60'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      {activeTab === 'pipeline' && <PipelineView projectId={id} />}

      {activeTab === 'products' && (
        <div className="space-y-3">
          {products.length === 0 ? (
            <div className="card text-center py-12">
              <p className="text-white/20 text-sm">No products yet. Run the Research Agent to discover products.</p>
            </div>
          ) : (
            products.map((product) => (
              <div key={product.id} className="card">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="font-semibold text-sm mb-1">{product.name}</h3>
                    <p className="text-xs text-white/30 line-clamp-2 mb-2">
                      {product.description?.replace(/<[^>]*>/g, '').slice(0, 200) || 'No description'}
                    </p>
                    <div className="flex items-center gap-4 text-xs font-mono text-white/40">
                      {product.price && <span>Price: ${product.price}</span>}
                      {product.cost && <span>Cost: ${product.cost}</span>}
                      {product.category && <span>Category: {product.category}</span>}
                      {product.overall_score && (
                        <span className="text-accent-amber">Score: {product.overall_score}/10</span>
                      )}
                    </div>
                  </div>
                  {product.shopify_product_id && (
                    <span className="badge bg-accent-green/10 text-accent-green border border-accent-green/20">
                      Synced
                    </span>
                  )}
                </div>

                {/* Score bars */}
                {product.overall_score && (
                  <div className="grid grid-cols-3 gap-4 mt-4 pt-4 border-t border-border">
                    {[
                      { label: 'Trend', score: product.trend_score, color: 'bg-agent-research' },
                      { label: 'Competition', score: product.competition_score, color: 'bg-agent-store' },
                      { label: 'Margin', score: product.margin_score, color: 'bg-agent-copy' },
                    ].map(({ label, score, color }) => (
                      <div key={label}>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-[10px] text-white/30">{label}</span>
                          <span className="text-[10px] font-mono text-white/50">{score}/10</span>
                        </div>
                        <div className="h-1 bg-bg-surface2 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${color}`}
                            style={{ width: `${(score / 10) * 100}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      )}

      {activeTab === 'tasks' && (
        <div className="space-y-2">
          {tasks.length === 0 ? (
            <div className="card text-center py-12">
              <p className="text-white/20 text-sm">No tasks yet.</p>
            </div>
          ) : (
            tasks.map((task) => (
              <div key={task.id} className="card py-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <StatusBadge status={task.status} />
                    <div>
                      <span className="text-sm font-medium">{task.task_name}</span>
                      <span className="text-xs text-white/30 ml-2 font-mono">{task.agent_type}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 text-xs font-mono text-white/30">
                    {task.duration_seconds && <span>{task.duration_seconds.toFixed(1)}s</span>}
                    {task.tokens_used > 0 && <span>{task.tokens_used.toLocaleString()} tokens</span>}
                    {task.api_cost > 0 && <span>${task.api_cost.toFixed(4)}</span>}
                  </div>
                </div>
                {task.error_message && (
                  <pre className="mt-2 text-xs text-accent-red/70 bg-accent-red/5 rounded-lg p-3 overflow-x-auto">
                    {task.error_message.slice(0, 300)}
                  </pre>
                )}
              </div>
            ))
          )}
        </div>
      )}

      {activeTab === 'approval' && (
        <ApprovalQueue tasks={tasks} onAction={fetchAll} />
      )}
    </div>
  );
}
