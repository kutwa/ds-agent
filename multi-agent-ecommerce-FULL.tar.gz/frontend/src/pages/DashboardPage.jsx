import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  FolderKanban, Package, Workflow, DollarSign, Plus, ArrowRight
} from 'lucide-react';
import StatCard from '../components/dashboard/StatCard';
import ProjectList from '../components/projects/ProjectList';
import StatusBadge from '../components/common/StatusBadge';
import { projectsApi } from '../services/api';
import { useWebSocket } from '../hooks/useWebSocket';

export default function DashboardPage() {
  const navigate = useNavigate();
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const { lastEvent, connected } = useWebSocket();

  const fetchProjects = async () => {
    try {
      const data = await projectsApi.list({ limit: 50 });
      setProjects(data.projects || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProjects();
  }, []);

  // Re-fetch when pipeline events come in
  useEffect(() => {
    if (lastEvent?.event?.includes('pipeline') || lastEvent?.event?.includes('agent_completed')) {
      fetchProjects();
    }
  }, [lastEvent]);

  const totalProjects = projects.length;
  const liveProjects = projects.filter((p) => p.status === 'live').length;
  const runningPipelines = projects.filter((p) =>
    ['researching', 'building_store', 'designing', 'writing_copy'].includes(p.status)
  ).length;
  const reviewProjects = projects.filter((p) => p.status === 'review').length;

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-sm text-white/40 mt-1">Multi-Agent E-Commerce Control Center</p>
        </div>
        <button
          onClick={() => navigate('/projects/new')}
          className="btn-primary flex items-center gap-2"
        >
          <Plus size={16} />
          New Project
        </button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          icon={FolderKanban}
          label="Total Projects"
          value={totalProjects}
          color="accent-blue"
        />
        <StatCard
          icon={Workflow}
          label="Running Pipelines"
          value={runningPipelines}
          subValue={runningPipelines > 0 ? 'Agents working...' : 'All idle'}
          color="agent-orchestrator"
        />
        <StatCard
          icon={Package}
          label="Live Stores"
          value={liveProjects}
          color="accent-green"
        />
        <StatCard
          icon={DollarSign}
          label="Pending Review"
          value={reviewProjects}
          subValue={reviewProjects > 0 ? 'Needs your approval' : 'All clear'}
          color="accent-amber"
        />
      </div>

      {/* Recent Projects */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">Recent Projects</h2>
          <button
            onClick={() => navigate('/projects')}
            className="text-xs text-white/40 hover:text-white/70 flex items-center gap-1 transition-colors"
          >
            View all <ArrowRight size={12} />
          </button>
        </div>
        {loading ? (
          <div className="card text-center py-12">
            <div className="animate-spin w-6 h-6 border-2 border-accent-blue border-t-transparent rounded-full mx-auto mb-3" />
            <p className="text-sm text-white/30">Loading projects...</p>
          </div>
        ) : (
          <ProjectList projects={projects.slice(0, 5)} onRefresh={fetchProjects} />
        )}
      </div>

      {/* Live Activity */}
      {lastEvent && (
        <div className="card border-accent-blue/10">
          <h3 className="text-sm font-semibold text-white/60 mb-2">Latest Activity</h3>
          <div className="flex items-center gap-3 text-xs font-mono">
            <div className="w-1.5 h-1.5 rounded-full bg-accent-blue glow-dot" style={{ color: '#6366f1' }} />
            <span className="text-white/40">
              [{lastEvent.agent_type || 'system'}]
            </span>
            <span className="text-white/60">{lastEvent.event}</span>
            {lastEvent.data?.step && (
              <span className="text-white/30">— {lastEvent.data.step}</span>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
