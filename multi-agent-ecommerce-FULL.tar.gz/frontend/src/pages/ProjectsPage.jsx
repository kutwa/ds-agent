import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, Filter } from 'lucide-react';
import ProjectList from '../components/projects/ProjectList';
import { projectsApi } from '../services/api';

const STATUS_FILTERS = [
  { value: '', label: 'All' },
  { value: 'draft', label: 'Draft' },
  { value: 'researching', label: 'Researching' },
  { value: 'building_store', label: 'Building' },
  { value: 'designing', label: 'Designing' },
  { value: 'writing_copy', label: 'Copywriting' },
  { value: 'review', label: 'Review' },
  { value: 'live', label: 'Live' },
  { value: 'failed', label: 'Failed' },
];

export default function ProjectsPage() {
  const navigate = useNavigate();
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');

  const fetchProjects = async () => {
    setLoading(true);
    try {
      const params = { limit: 100 };
      if (filter) params.status = filter;
      const data = await projectsApi.list(params);
      setProjects(data.projects || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProjects();
  }, [filter]);

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Projects</h1>
          <p className="text-sm text-white/40 mt-1">{projects.length} total projects</p>
        </div>
        <button
          onClick={() => navigate('/projects/new')}
          className="btn-primary flex items-center gap-2"
        >
          <Plus size={16} />
          New Project
        </button>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2">
        <Filter size={14} className="text-white/30 shrink-0" />
        {STATUS_FILTERS.map(({ value, label }) => (
          <button
            key={value}
            onClick={() => setFilter(value)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
              filter === value
                ? 'bg-accent-blue/10 text-accent-blue border border-accent-blue/20'
                : 'text-white/40 hover:text-white/60 hover:bg-bg-surface2 border border-transparent'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="card text-center py-12">
          <div className="animate-spin w-6 h-6 border-2 border-accent-blue border-t-transparent rounded-full mx-auto mb-3" />
          <p className="text-sm text-white/30">Loading...</p>
        </div>
      ) : (
        <ProjectList projects={projects} onRefresh={fetchProjects} />
      )}
    </div>
  );
}
