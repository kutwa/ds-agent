const API_BASE = '/api';

class ApiError extends Error {
  constructor(status, message, data) {
    super(message);
    this.status = status;
    this.data = data;
  }
}

async function request(method, path, body = null) {
  const opts = {
    method,
    headers: { 'Content-Type': 'application/json' },
  };
  if (body) opts.body = JSON.stringify(body);

  const res = await fetch(`${API_BASE}${path}`, opts);

  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new ApiError(res.status, data.detail || 'Request failed', data);
  }

  if (res.status === 204) return null;
  return res.json();
}

// ── Projects ────────────────────────────────

export const projectsApi = {
  list: (params = {}) => {
    const qs = new URLSearchParams(params).toString();
    return request('GET', `/projects${qs ? `?${qs}` : ''}`);
  },
  get: (id) => request('GET', `/projects/${id}`),
  create: (data) => request('POST', '/projects', data),
  update: (id, data) => request('PATCH', `/projects/${id}`, data),
  delete: (id) => request('DELETE', `/projects/${id}`),
  getProducts: (id) => request('GET', `/projects/${id}/products`),
  getTasks: (id) => request('GET', `/projects/${id}/tasks`),
};

// ── Pipeline ────────────────────────────────

export const pipelineApi = {
  start: (projectId) => request('POST', '/pipeline/start', { project_id: projectId }),
  status: (projectId) => request('GET', `/pipeline/status/${projectId}`),
  resume: (projectId, fromAgent) =>
    request('POST', `/pipeline/resume/${projectId}?from_agent=${fromAgent}`),
  approve: (taskId, approved, approvedBy = 'admin') =>
    request('POST', `/pipeline/approve/${taskId}`, { approved, approved_by: approvedBy }),
  stop: (projectId) => request('POST', `/pipeline/stop/${projectId}`),
};

// ── Health ──────────────────────────────────

export const healthApi = {
  check: () => fetch('/health').then((r) => r.json()),
};
