import clsx from 'clsx';
import { Search, Store, Palette, PenTool, Loader2, CheckCircle2, XCircle, Clock } from 'lucide-react';

const agentConfig = {
  research: {
    icon: Search,
    label: 'Research Agent',
    color: 'agent-research',
    description: 'Market analysis & product discovery',
  },
  store_builder: {
    icon: Store,
    label: 'Store Builder',
    color: 'agent-store',
    description: 'Shopify store setup & configuration',
  },
  design: {
    icon: Palette,
    label: 'Design Agent',
    color: 'agent-design',
    description: 'Brand identity & theme creation',
  },
  copy: {
    icon: PenTool,
    label: 'Copy Agent',
    color: 'agent-copy',
    description: 'SEO content & product descriptions',
  },
};

const statusIcons = {
  idle: Clock,
  running: Loader2,
  completed: CheckCircle2,
  failed: XCircle,
};

export default function AgentCard({ type, progress = null, className }) {
  const config = agentConfig[type];
  if (!config) return null;

  const Icon = config.icon;
  const status = progress?.status || 'idle';
  const StatusIcon = statusIcons[status] || Clock;
  const pct = progress?.progress || 0;
  const step = progress?.step || '';

  return (
    <div
      className={clsx(
        'card relative overflow-hidden',
        status === 'running' && `border-${config.color}/30`,
        status === 'completed' && 'border-accent-green/20',
        status === 'failed' && 'border-accent-red/20',
        className
      )}
    >
      {/* Top color bar */}
      <div
        className={clsx('absolute top-0 left-0 right-0 h-0.5', `bg-${config.color}`)}
        style={{ opacity: status === 'idle' ? 0.3 : 1 }}
      />

      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          <div
            className={clsx(
              'w-10 h-10 rounded-xl flex items-center justify-center',
              `bg-${config.color}/10 border border-${config.color}/20`
            )}
          >
            <Icon size={18} className={`text-${config.color}`} />
          </div>
          <div>
            <h3 className="font-semibold text-sm">{config.label}</h3>
            <p className="text-xs text-white/40">{config.description}</p>
          </div>
        </div>

        <StatusIcon
          size={18}
          className={clsx(
            status === 'running' && 'text-accent-blue animate-spin',
            status === 'completed' && 'text-accent-green',
            status === 'failed' && 'text-accent-red',
            status === 'idle' && 'text-white/20'
          )}
        />
      </div>

      {/* Progress bar */}
      {status === 'running' && (
        <div className="mt-3">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-xs text-white/50 font-mono truncate max-w-[70%]">{step}</span>
            <span className="text-xs text-white/50 font-mono">{pct}%</span>
          </div>
          <div className="h-1 bg-bg-surface2 rounded-full overflow-hidden">
            <div
              className={clsx('h-full rounded-full transition-all duration-500', `bg-${config.color}`)}
              style={{ width: `${pct}%` }}
            />
          </div>
        </div>
      )}

      {status === 'completed' && (
        <p className="mt-2 text-xs text-accent-green/70 font-mono">✓ Completed</p>
      )}

      {status === 'failed' && (
        <p className="mt-2 text-xs text-accent-red/70 font-mono truncate">{step}</p>
      )}
    </div>
  );
}
