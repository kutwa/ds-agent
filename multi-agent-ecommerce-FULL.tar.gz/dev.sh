#!/bin/bash
# ═══════════════════════════════════════
#  Dev helper commands
# ═══════════════════════════════════════

case "$1" in
  start)
    echo "🚀 Starting all services..."
    docker compose up -d
    echo "✅ Running at http://localhost:5173"
    ;;
  stop)
    echo "⏹  Stopping all services..."
    docker compose down
    echo "✅ Stopped"
    ;;
  restart)
    echo "🔄 Restarting..."
    docker compose restart
    ;;
  logs)
    docker compose logs -f ${2:-backend}
    ;;
  rebuild)
    echo "🔨 Rebuilding..."
    docker compose down
    docker compose build --no-cache
    docker compose up -d
    echo "✅ Rebuilt and running"
    ;;
  db-reset)
    echo "🗄  Resetting database..."
    docker compose exec -T backend python init_db.py
    echo "✅ Database reset"
    ;;
  shell)
    echo "🐚 Opening backend shell..."
    docker compose exec backend bash
    ;;
  test-api)
    echo "🧪 Testing API..."
    echo ""
    echo "Health check:"
    curl -s http://localhost:8000/health | python3 -m json.tool
    echo ""
    echo "Projects:"
    curl -s http://localhost:8000/api/projects | python3 -m json.tool
    ;;
  *)
    echo "Usage: ./dev.sh {start|stop|restart|logs|rebuild|db-reset|shell|test-api}"
    echo ""
    echo "  start      Start all services"
    echo "  stop       Stop all services"
    echo "  restart    Restart all services"
    echo "  logs [svc] Tail logs (default: backend)"
    echo "  rebuild    Full rebuild and start"
    echo "  db-reset   Reinitialize database tables"
    echo "  shell      Open bash in backend container"
    echo "  test-api   Quick API health check"
    ;;
esac
