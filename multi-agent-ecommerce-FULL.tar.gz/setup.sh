#!/bin/bash
set -e

# ═══════════════════════════════════════════
#  Multi-Agent E-Commerce System — Setup
# ═══════════════════════════════════════════

BOLD='\033[1m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[0;33m'
RED='\033[0;31m'
NC='\033[0m'

echo ""
echo -e "${CYAN}${BOLD}🤖 Multi-Agent E-Commerce System${NC}"
echo -e "${CYAN}   Automated Setup Script${NC}"
echo ""

# ── Check prerequisites ───────────────────

check_command() {
    if command -v "$1" &> /dev/null; then
        echo -e "  ${GREEN}✓${NC} $1 found"
        return 0
    else
        echo -e "  ${RED}✗${NC} $1 not found"
        return 1
    fi
}

echo -e "${BOLD}Checking prerequisites...${NC}"
MISSING=0

check_command "docker" || MISSING=1
check_command "docker" && docker compose version &>/dev/null && echo -e "  ${GREEN}✓${NC} docker compose found" || { echo -e "  ${RED}✗${NC} docker compose not found"; MISSING=1; }

if [ $MISSING -eq 1 ]; then
    echo ""
    echo -e "${RED}Missing prerequisites. Please install Docker and Docker Compose.${NC}"
    echo "  https://docs.docker.com/get-docker/"
    exit 1
fi

echo ""

# ── Environment setup ─────────────────────

if [ ! -f .env ]; then
    echo -e "${YELLOW}Creating .env from template...${NC}"
    cp .env.example .env
    echo -e "${GREEN}✓${NC} .env created"
    echo ""
    echo -e "${YELLOW}${BOLD}⚠  IMPORTANT: Edit .env and add your API keys before running!${NC}"
    echo ""
    echo "  Required keys:"
    echo "    ANTHROPIC_API_KEY     — https://console.anthropic.com/"
    echo "    SHOPIFY_API_KEY       — https://partners.shopify.com/"
    echo "    SHOPIFY_API_SECRET"
    echo "    SHOPIFY_ACCESS_TOKEN"
    echo "    SHOPIFY_SHOP_URL"
    echo ""
    echo "  Optional:"
    echo "    OPENAI_API_KEY        — For AI image generation"
    echo ""
    read -p "Have you edited .env with your API keys? (y/N): " EDITED
    if [[ ! "$EDITED" =~ ^[Yy]$ ]]; then
        echo ""
        echo -e "${YELLOW}Please edit .env first, then run this script again.${NC}"
        echo "  nano .env"
        exit 0
    fi
else
    echo -e "${GREEN}✓${NC} .env already exists"
fi

echo ""

# ── Validate critical env vars ────────────

echo -e "${BOLD}Validating configuration...${NC}"

source .env 2>/dev/null || true

VALID=1
check_env() {
    local var_name=$1
    local var_value="${!var_name}"
    if [ -z "$var_value" ] || [[ "$var_value" == *"YOUR_"* ]] || [[ "$var_value" == *"CHANGE_ME"* ]]; then
        echo -e "  ${RED}✗${NC} $var_name — not configured"
        VALID=0
    else
        echo -e "  ${GREEN}✓${NC} $var_name — set"
    fi
}

check_env "ANTHROPIC_API_KEY"
check_env "SHOPIFY_API_KEY"
check_env "SHOPIFY_ACCESS_TOKEN"
check_env "SHOPIFY_SHOP_URL"

echo ""

if [ $VALID -eq 0 ]; then
    echo -e "${YELLOW}Some required keys are missing. The system will start but agents may fail.${NC}"
    read -p "Continue anyway? (y/N): " CONT
    if [[ ! "$CONT" =~ ^[Yy]$ ]]; then
        echo "Edit .env and try again."
        exit 0
    fi
fi

# ── Build and start ───────────────────────

echo -e "${BOLD}Building and starting services...${NC}"
echo ""

docker compose build --no-cache
echo ""

docker compose up -d
echo ""

# ── Wait for services ─────────────────────

echo -e "${BOLD}Waiting for services to start...${NC}"

wait_for_service() {
    local name=$1
    local url=$2
    local max_attempts=30
    local attempt=0

    while [ $attempt -lt $max_attempts ]; do
        if curl -s "$url" > /dev/null 2>&1; then
            echo -e "  ${GREEN}✓${NC} $name is ready"
            return 0
        fi
        attempt=$((attempt + 1))
        sleep 2
    done

    echo -e "  ${YELLOW}⚠${NC} $name is still starting (may take longer)"
    return 0
}

wait_for_service "PostgreSQL" "localhost:5432"
wait_for_service "Redis" "localhost:6379"
wait_for_service "Backend API" "http://localhost:8000/health"
wait_for_service "Frontend" "http://localhost:5173"

echo ""

# ── Initialize database ──────────────────

echo -e "${BOLD}Initializing database...${NC}"
docker compose exec -T backend python init_db.py 2>/dev/null || echo -e "  ${YELLOW}⚠${NC} DB init will run on first request"

echo ""

# ── Done! ─────────────────────────────────

echo -e "${GREEN}${BOLD}═══════════════════════════════════════════${NC}"
echo -e "${GREEN}${BOLD}  🎉 System is ready!${NC}"
echo -e "${GREEN}${BOLD}═══════════════════════════════════════════${NC}"
echo ""
echo -e "  ${BOLD}Dashboard:${NC}   http://localhost:5173"
echo -e "  ${BOLD}API Docs:${NC}    http://localhost:8000/docs"
echo -e "  ${BOLD}MinIO:${NC}       http://localhost:9001 (minioadmin/minioadmin)"
echo ""
echo -e "  ${BOLD}Commands:${NC}"
echo "    docker compose logs -f backend    # Backend logs"
echo "    docker compose logs -f frontend   # Frontend logs"
echo "    docker compose down               # Stop all"
echo "    docker compose restart backend    # Restart backend"
echo ""
echo -e "  ${BOLD}Quick start:${NC}"
echo "    1. Open http://localhost:5173"
echo "    2. Click 'New Project'"
echo "    3. Enter a niche (e.g. 'Eco-friendly yoga mats')"
echo "    4. Go to Pipeline tab → Start Pipeline"
echo "    5. Watch the agents work in real-time!"
echo ""
