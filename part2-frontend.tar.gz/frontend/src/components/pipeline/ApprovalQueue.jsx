import { useState } from 'react';
import { Check, X, AlertTriangle } from 'lucide-react';
import { pipelineApi } from '../../services/api';
import StatusBadge from '../common/StatusBadge';

export default function ApprovalQueue({ tasks = [], onAction }) {
  const [processing, setProcessing] = useState(null);

  const pendingTasks = tasks.filter((t) => t.status === 'awaiting_approval');

  const handleApprove = async (taskId) => {
    setProcessing(taskId);
    try {
      await pipelineApi.approve(taskId, true);
      onAction?.();
    } catch (err) {
      console.error(err);
    } finally {
      setProcessing(null);
    }
  };

  const handleReject = async (taskId) => {
    setProcessing(taskId);
    try {
      await pipelineApi.approve(taskId, false);
      onAction?.();
    } catch (err) {
      console.error(err);
    } finally {
      setProcessing(null);
    }
  };

  if (pendingTasks.length === 0) {
    return (
      <div className="card">
        <div className="text-center py-8">
          <p className="text-white/20 text-sm">No tasks awaiting approval</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 mb-2">
        <AlertTriangle size={16} className="text-accent-amber" />
        <h3 className="text-sm font-semibold">
          {pendingTasks.length} task{pendingTasks.length !== 1 ? 's' : ''} awaiting approval
        </h3>
      </div>

      {pendingTasks.map((task) => (
        <div key={task.id} className="card border-accent-amber/20">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <h4 className="text-sm font-semibold">{task.task_name}</h4>
                <StatusBadge status={task.status} />
              </div>
              <p className="text-xs text-white/30 font-mono mb-2">
                Agent: {task.agent_type} · Tokens: {task.tokens_used?.toLocaleString()} · 
                Cost: ${task.api_cost?.toFixed(4)}
              </p>

              {/* Show output preview */}
              {task.output_data?.summary && (
                <p className="text-xs text-white/50 bg-bg-surface2 rounded-lg p-3 mb-3">
                  {task.output_data.summary}
                </p>
              )}
            </div>

            <div className="flex gap-2 ml-4">
              <button
                onClick={() => handleApprove(task.id)}
                disabled={processing === task.id}
                className="flex items-center gap-1.5 px-4 py-2 bg-accent-green/10 text-accent-green
                           border border-accent-green/20 rounded-xl text-xs font-medium
                           hover:bg-accent-green/20 transition-all disabled:opacity-50"
              >
                <Check size={14} />
                Approve
              </button>
              <button
                onClick={() => handleReject(task.id)}
                disabled={processing === task.id}
                className="flex items-center gap-1.5 px-4 py-2 bg-accent-red/10 text-accent-red
                           border border-accent-red/20 rounded-xl text-xs font-medium
                           hover:bg-accent-red/20 transition-all disabled:opacity-50"
              >
                <X size={14} />
                Reject
              </button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
