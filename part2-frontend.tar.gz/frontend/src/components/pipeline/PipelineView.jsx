import { useState, useEffect } from 'react';
import { ArrowDown, Play, Square, RotateCcw } from 'lucide-react';
import AgentCard from './AgentCard';
import { pipelineApi } from '../../services/api';
import { usePipelineEvents } from '../../hooks/useWebSocket';

const AGENTS_ORDER = ['research', 'store_builder', 'design', 'copy'];

export default function PipelineView({ projectId }) {
  const { agentProgress, pipelineStatus, connected, events } = usePipelineEvents(projectId);
  const [starting, setStarting] = useState(false);
  const [statusData, setStatusData] = useState(null);

  // Fetch initial status
  useEffect(() => {
    if (projectId) {
      pipelineApi.status(projectId).then(setStatusData).catch(() => {});
    }
  }, [projectId]);

  const handleStart = async () => {
    setStarting(true);
    try {
      await pipelineApi.start(projectId);
    } catch (err) {
      console.error('Failed to start pipeline:', err);
    } finally {
      setStarting(false);
    }
  };

  const handleStop = async () => {
    try {
      await pipelineApi.stop(projectId);
    } catch (err) {
      console.error('Failed to stop:', err);
    }
  };

  const isRunning = pipelineStatus === 'running';
  const isCompleted = pipelineStatus === 'completed';

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold">Agent Pipeline</h2>
          <div className="flex items-center gap-2 mt-1">
            <div
              className={`w-1.5 h-1.5 rounded-full ${
                connected ? 'bg-green-400' : 'bg-red-400'
              }`}
              style={{ boxShadow: connected ? '0 0 6px #34d399' : '0 0 6px #ef4444' }}
            />
            <span className="text-xs font-mono text-white/30">
              {connected ? 'Live' : 'Disconnected'}
            </span>
          </div>
        </div>

        <div className="flex gap-2">
          {!isRunning && (
            <button
              onClick={handleStart}
              disabled={starting || !projectId}
              className="btn-primary flex items-center gap-2"
            >
              <Play size={14} />
              {starting ? 'Starting...' : 'Start Pipeline'}
            </button>
          )}
          {isRunning && (
            <button onClick={handleStop} className="btn-danger flex items-center gap-2">
              <Square size={14} />
              Stop
            </button>
          )}
        </div>
      </div>

      {/* Agent Cards */}
      <div className="space-y-3">
        {AGENTS_ORDER.map((agentType, idx) => (
          <div key={agentType}>
            <AgentCard type={agentType} progress={agentProgress[agentType]} />
            {idx < AGENTS_ORDER.length - 1 && (
              <div className="flex justify-center py-2">
                <ArrowDown size={16} className="text-white/10" />
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Event Log */}
      <div className="card mt-6">
        <h3 className="text-sm font-semibold mb-3 text-white/60">Live Event Log</h3>
        <div className="max-h-48 overflow-y-auto space-y-1">
          {events.length === 0 && (
            <p className="text-xs text-white/20 font-mono">No events yet. Start the pipeline to see live updates.</p>
          )}
          {events.map((ev, i) => (
            <div key={i} className="flex items-start gap-2 text-xs font-mono">
              <span className="text-white/20 shrink-0">
                {new Date(ev.timestamp).toLocaleTimeString()}
              </span>
              <span className="text-accent-blue/70">[{ev.agent_type || 'system'}]</span>
              <span className="text-white/50">{ev.event}</span>
              {ev.data?.step && (
                <span className="text-white/30 truncate">— {ev.data.step}</span>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
