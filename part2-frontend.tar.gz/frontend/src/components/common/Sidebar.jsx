import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard, FolderKanban, Workflow, Settings, Zap, Activity
} from 'lucide-react';

const navItems = [
  { to: '/', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/projects', icon: FolderKanban, label: 'Projects' },
  { to: '/pipeline', icon: Workflow, label: 'Pipeline' },
  { to: '/logs', icon: Activity, label: 'Logs' },
  { to: '/settings', icon: Settings, label: 'Settings' },
];

export default function Sidebar() {
  return (
    <aside className="fixed left-0 top-0 bottom-0 w-64 bg-bg-surface border-r border-border flex flex-col z-50">
      {/* Logo */}
      <div className="px-6 py-6 border-b border-border">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-accent-blue/10 border border-accent-blue/20 flex items-center justify-center">
            <Zap size={18} className="text-accent-blue" />
          </div>
          <div>
            <h1 className="text-base font-bold tracking-tight">AgentCommerce</h1>
            <p className="text-[10px] font-mono text-white/30 tracking-widest uppercase">Control Panel</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-4 space-y-1">
        {navItems.map(({ to, icon: Icon, label }) => (
          <NavLink
            key={to}
            to={to}
            end={to === '/'}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                isActive
                  ? 'bg-accent-blue/10 text-accent-blue border border-accent-blue/20'
                  : 'text-white/50 hover:text-white/80 hover:bg-bg-surface2 border border-transparent'
              }`
            }
          >
            <Icon size={18} />
            <span>{label}</span>
          </NavLink>
        ))}
      </nav>

      {/* Status */}
      <div className="px-4 py-4 border-t border-border">
        <div className="flex items-center gap-2 text-xs text-white/30">
          <div className="w-1.5 h-1.5 rounded-full bg-green-400 glow-dot" style={{ color: '#34d399' }} />
          <span className="font-mono">System Online</span>
        </div>
      </div>
    </aside>
  );
}
