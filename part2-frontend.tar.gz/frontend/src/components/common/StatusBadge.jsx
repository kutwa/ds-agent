import clsx from 'clsx';

const statusConfig = {
  draft: { color: 'text-white/50 bg-white/5 border-white/10', dot: 'bg-white/40' },
  researching: { color: 'text-agent-research bg-agent-research/10 border-agent-research/20', dot: 'bg-agent-research' },
  building_store: { color: 'text-agent-store bg-agent-store/10 border-agent-store/20', dot: 'bg-agent-store' },
  designing: { color: 'text-agent-design bg-agent-design/10 border-agent-design/20', dot: 'bg-agent-design' },
  writing_copy: { color: 'text-agent-copy bg-agent-copy/10 border-agent-copy/20', dot: 'bg-agent-copy' },
  review: { color: 'text-accent-amber bg-accent-amber/10 border-accent-amber/20', dot: 'bg-accent-amber' },
  live: { color: 'text-accent-green bg-accent-green/10 border-accent-green/20', dot: 'bg-accent-green' },
  paused: { color: 'text-white/50 bg-white/5 border-white/10', dot: 'bg-white/40' },
  failed: { color: 'text-accent-red bg-accent-red/10 border-accent-red/20', dot: 'bg-accent-red' },
  // Task statuses
  pending: { color: 'text-white/50 bg-white/5 border-white/10', dot: 'bg-white/40' },
  running: { color: 'text-accent-blue bg-accent-blue/10 border-accent-blue/20', dot: 'bg-accent-blue' },
  completed: { color: 'text-accent-green bg-accent-green/10 border-accent-green/20', dot: 'bg-accent-green' },
  awaiting_approval: { color: 'text-accent-amber bg-accent-amber/10 border-accent-amber/20', dot: 'bg-accent-amber' },
  approved: { color: 'text-accent-green bg-accent-green/10 border-accent-green/20', dot: 'bg-accent-green' },
  rejected: { color: 'text-accent-red bg-accent-red/10 border-accent-red/20', dot: 'bg-accent-red' },
};

const labels = {
  draft: 'Draft',
  researching: 'Researching',
  building_store: 'Building Store',
  designing: 'Designing',
  writing_copy: 'Writing Copy',
  review: 'In Review',
  live: 'Live',
  paused: 'Paused',
  failed: 'Failed',
  pending: 'Pending',
  running: 'Running',
  completed: 'Completed',
  awaiting_approval: 'Awaiting Approval',
  approved: 'Approved',
  rejected: 'Rejected',
};

export default function StatusBadge({ status, className }) {
  const config = statusConfig[status] || statusConfig.draft;
  return (
    <span className={clsx('badge border', config.color, className)}>
      <span className={clsx('w-1.5 h-1.5 rounded-full', config.dot)} />
      {labels[status] || status}
    </span>
  );
}
