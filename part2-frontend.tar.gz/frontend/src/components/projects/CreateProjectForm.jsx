import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Rocket, ArrowLeft } from 'lucide-react';
import { projectsApi } from '../../services/api';

export default function CreateProjectForm() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    name: '',
    niche: '',
    description: '',
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name.trim() || !form.niche.trim()) return;

    setLoading(true);
    try {
      const project = await projectsApi.create(form);
      navigate(`/projects/${project.id}`);
    } catch (err) {
      console.error(err);
      alert('Failed to create project');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-xl mx-auto">
      <button
        onClick={() => navigate('/projects')}
        className="flex items-center gap-2 text-sm text-white/40 hover:text-white/70 mb-6 transition-colors"
      >
        <ArrowLeft size={16} />
        Back to Projects
      </button>

      <div className="card">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-accent-blue/10 border border-accent-blue/20 flex items-center justify-center">
            <Rocket size={18} className="text-accent-blue" />
          </div>
          <div>
            <h2 className="text-lg font-bold">New Project</h2>
            <p className="text-xs text-white/40">Define your niche and let the agents do the rest</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="label">Project Name</label>
            <input
              type="text"
              className="input"
              placeholder="e.g. Premium Pet Accessories"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              required
            />
          </div>

          <div>
            <label className="label">Niche / Market</label>
            <input
              type="text"
              className="input"
              placeholder="e.g. Eco-friendly dog toys for urban millennials"
              value={form.niche}
              onChange={(e) => setForm({ ...form, niche: e.target.value })}
              required
            />
            <p className="text-xs text-white/20 mt-1.5">
              Be specific — the more detail, the better the research agent performs.
            </p>
          </div>

          <div>
            <label className="label">Description (optional)</label>
            <textarea
              className="input min-h-[100px] resize-y"
              placeholder="Any additional context: target audience, price range, competitors to study..."
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
            />
          </div>

          <button type="submit" disabled={loading} className="btn-primary w-full flex items-center justify-center gap-2">
            <Rocket size={16} />
            {loading ? 'Creating...' : 'Create Project'}
          </button>
        </form>
      </div>
    </div>
  );
}
