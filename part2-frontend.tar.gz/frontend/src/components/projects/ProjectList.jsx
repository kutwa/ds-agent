import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, ExternalLink, Trash2 } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import StatusBadge from '../common/StatusBadge';
import { projectsApi } from '../../services/api';

export default function ProjectList({ projects, onRefresh }) {
  const navigate = useNavigate();
  const [deleting, setDeleting] = useState(null);

  const handleDelete = async (e, id) => {
    e.stopPropagation();
    if (!confirm('Delete this project and all its data?')) return;
    setDeleting(id);
    try {
      await projectsApi.delete(id);
      onRefresh?.();
    } catch (err) {
      console.error(err);
    } finally {
      setDeleting(null);
    }
  };

  if (!projects?.length) {
    return (
      <div className="card text-center py-16">
        <p className="text-white/30 mb-4">No projects yet</p>
        <button onClick={() => navigate('/projects/new')} className="btn-primary inline-flex items-center gap-2">
          <Plus size={16} />
          Create First Project
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {projects.map((project) => (
        <div
          key={project.id}
          onClick={() => navigate(`/projects/${project.id}`)}
          className="card cursor-pointer hover:border-border-glow group"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div>
                <div className="flex items-center gap-3 mb-1">
                  <h3 className="font-semibold text-sm group-hover:text-accent-blue transition-colors">
                    {project.name}
                  </h3>
                  <StatusBadge status={project.status} />
                </div>
                <p className="text-xs text-white/30 font-mono">
                  Niche: {project.niche} · Created{' '}
                  {formatDistanceToNow(new Date(project.created_at), { addSuffix: true })}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
              {project.shopify_store_url && (
                <a
                  href={project.shopify_store_url}
                  target="_blank"
                  rel="noopener"
                  onClick={(e) => e.stopPropagation()}
                  className="p-2 hover:bg-bg-surface2 rounded-lg transition-colors"
                >
                  <ExternalLink size={14} className="text-white/40" />
                </a>
              )}
              <button
                onClick={(e) => handleDelete(e, project.id)}
                disabled={deleting === project.id}
                className="p-2 hover:bg-red-500/10 rounded-lg transition-colors"
              >
                <Trash2 size={14} className="text-white/40 hover:text-red-400" />
              </button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
