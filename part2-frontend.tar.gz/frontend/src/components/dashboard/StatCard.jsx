import clsx from 'clsx';

export default function StatCard({ icon: Icon, label, value, subValue, color = 'accent-blue', trend }) {
  return (
    <div className="card">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs text-white/40 font-medium mb-1">{label}</p>
          <p className="text-2xl font-bold tracking-tight">{value}</p>
          {subValue && <p className="text-xs text-white/30 mt-1 font-mono">{subValue}</p>}
        </div>
        {Icon && (
          <div className={clsx(
            'w-10 h-10 rounded-xl flex items-center justify-center',
            `bg-${color}/10 border border-${color}/20`
          )}>
            <Icon size={18} className={`text-${color}`} />
          </div>
        )}
      </div>
      {trend && (
        <div className={clsx(
          'mt-3 text-xs font-mono',
          trend > 0 ? 'text-accent-green' : trend < 0 ? 'text-accent-red' : 'text-white/30'
        )}>
          {trend > 0 ? '↑' : trend < 0 ? '↓' : '→'} {Math.abs(trend)}% vs last period
        </div>
      )}
    </div>
  );
}
