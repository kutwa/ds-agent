import { useState, useEffect, useRef, useCallback } from 'react';

const WS_BASE = `${window.location.protocol === 'https:' ? 'wss' : 'ws'}://${window.location.host}`;

export function useWebSocket(projectId = null) {
  const [events, setEvents] = useState([]);
  const [lastEvent, setLastEvent] = useState(null);
  const [connected, setConnected] = useState(false);
  const wsRef = useRef(null);
  const reconnectTimer = useRef(null);

  const connect = useCallback(() => {
    const url = projectId ? `${WS_BASE}/ws/${projectId}` : `${WS_BASE}/ws`;

    try {
      const ws = new WebSocket(url);
      wsRef.current = ws;

      ws.onopen = () => {
        setConnected(true);
        console.log(`[WS] Connected to ${url}`);
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          setLastEvent(data);
          setEvents((prev) => [...prev.slice(-99), data]); // keep last 100
        } catch (e) {
          console.error('[WS] Parse error:', e);
        }
      };

      ws.onclose = () => {
        setConnected(false);
        console.log('[WS] Disconnected, reconnecting in 3s...');
        reconnectTimer.current = setTimeout(connect, 3000);
      };

      ws.onerror = (err) => {
        console.error('[WS] Error:', err);
        ws.close();
      };
    } catch (e) {
      console.error('[WS] Connection failed:', e);
      reconnectTimer.current = setTimeout(connect, 3000);
    }
  }, [projectId]);

  useEffect(() => {
    connect();
    return () => {
      if (wsRef.current) wsRef.current.close();
      if (reconnectTimer.current) clearTimeout(reconnectTimer.current);
    };
  }, [connect]);

  const clearEvents = useCallback(() => {
    setEvents([]);
    setLastEvent(null);
  }, []);

  return { events, lastEvent, connected, clearEvents };
}

export function usePipelineEvents(projectId) {
  const { events, lastEvent, connected } = useWebSocket(projectId);
  const [agentProgress, setAgentProgress] = useState({});
  const [pipelineStatus, setPipelineStatus] = useState('idle');

  useEffect(() => {
    if (!lastEvent) return;

    switch (lastEvent.event) {
      case 'pipeline_started':
        setPipelineStatus('running');
        setAgentProgress({});
        break;
      case 'agent_started':
        setAgentProgress((prev) => ({
          ...prev,
          [lastEvent.agent_type]: { status: 'running', progress: 0, step: 'Starting...' },
        }));
        break;
      case 'agent_progress':
        setAgentProgress((prev) => ({
          ...prev,
          [lastEvent.agent_type]: {
            status: 'running',
            progress: lastEvent.data?.progress || 0,
            step: lastEvent.data?.step || '',
          },
        }));
        break;
      case 'agent_completed':
        setAgentProgress((prev) => ({
          ...prev,
          [lastEvent.agent_type]: { status: 'completed', progress: 100, step: 'Done' },
        }));
        break;
      case 'agent_failed':
        setAgentProgress((prev) => ({
          ...prev,
          [lastEvent.agent_type]: {
            status: 'failed',
            progress: 0,
            step: lastEvent.data?.error || 'Failed',
          },
        }));
        break;
      case 'pipeline_completed':
        setPipelineStatus('completed');
        break;
      case 'pipeline_failed':
        setPipelineStatus('failed');
        break;
      case 'pipeline_paused_for_approval':
        setPipelineStatus('awaiting_approval');
        break;
    }
  }, [lastEvent]);

  return { events, lastEvent, connected, agentProgress, pipelineStatus };
}
