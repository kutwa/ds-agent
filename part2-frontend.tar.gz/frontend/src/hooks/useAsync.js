import { useState, useEffect, useCallback } from 'react';

export function useAsync(asyncFn, deps = [], immediate = true) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(immediate);
  const [error, setError] = useState(null);

  const execute = useCallback(async (...args) => {
    setLoading(true);
    setError(null);
    try {
      const result = await asyncFn(...args);
      setData(result);
      return result;
    } catch (err) {
      setError(err);
      throw err;
    } finally {
      setLoading(false);
    }
  }, deps);

  useEffect(() => {
    if (immediate) {
      execute();
    }
  }, [execute, immediate]);

  return { data, loading, error, execute, setData };
}

export function usePolling(asyncFn, interval = 5000, enabled = true) {
  const { data, loading, error, execute } = useAsync(asyncFn, [], false);

  useEffect(() => {
    if (!enabled) return;
    execute();
    const id = setInterval(execute, interval);
    return () => clearInterval(id);
  }, [enabled, interval, execute]);

  return { data, loading, error, refresh: execute };
}
