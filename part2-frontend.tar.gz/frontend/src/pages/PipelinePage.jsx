import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Workflow, Play } from 'lucide-react';
import StatusBadge from '../components/common/StatusBadge';
import { projectsApi } from '../services/api';

export default function PipelinePage() {
  const navigate = useNavigate();
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    projectsApi.list({ limit: 100 }).then((data) => {
      setProjects(data.projects || []);
      setLoading(false);
    });
  }, []);

  const activeProjects = projects.filter((p) =>
    ['researching', 'building_store', 'designing', 'writing_copy', 'review'].includes(p.status)
  );
  const draftProjects = projects.filter((p) => p.status === 'draft');

  return (
    <div className="space-y-8 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Pipeline Manager</h1>
        <p className="text-sm text-white/40 mt-1">Monitor and control agent pipelines</p>
      </div>

      {/* Active Pipelines */}
      <div>
        <h2 className="text-sm font-semibold text-white/60 mb-3 flex items-center gap-2">
          <Workflow size={14} />
          Active Pipelines ({activeProjects.length})
        </h2>
        {activeProjects.length === 0 ? (
          <div className="card text-center py-10">
            <p className="text-white/20 text-sm">No active pipelines</p>
          </div>
        ) : (
          <div className="space-y-3">
            {activeProjects.map((p) => (
              <div
                key={p.id}
                onClick={() => navigate(`/projects/${p.id}`)}
                className="card cursor-pointer hover:border-border-glow"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-3 mb-1">
                      <h3 className="font-semibold text-sm">{p.name}</h3>
                      <StatusBadge status={p.status} />
                    </div>
                    <p className="text-xs text-white/30 font-mono">Niche: {p.niche}</p>
                  </div>
                  <span className="text-xs text-white/20">→</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Ready to Start */}
      <div>
        <h2 className="text-sm font-semibold text-white/60 mb-3 flex items-center gap-2">
          <Play size={14} />
          Ready to Start ({draftProjects.length})
        </h2>
        {draftProjects.length === 0 ? (
          <div className="card text-center py-10">
            <p className="text-white/20 text-sm">No draft projects. Create one from the Projects page.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {draftProjects.map((p) => (
              <div
                key={p.id}
                onClick={() => navigate(`/projects/${p.id}`)}
                className="card cursor-pointer hover:border-border-glow"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold text-sm">{p.name}</h3>
                    <p className="text-xs text-white/30 font-mono">{p.niche}</p>
                  </div>
                  <StatusBadge status="draft" />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
