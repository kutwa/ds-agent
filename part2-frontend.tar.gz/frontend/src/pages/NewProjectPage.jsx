import CreateProjectForm from '../components/projects/CreateProjectForm';

export default function NewProjectPage() {
  return <CreateProjectForm />;
}
