import { Activity } from 'lucide-react';
import { useWebSocket } from '../hooks/useWebSocket';

export default function LogsPage() {
  const { events, connected } = useWebSocket();

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Event Logs</h1>
          <p className="text-sm text-white/40 mt-1">Real-time agent activity feed</p>
        </div>
        <div className="flex items-center gap-2 text-xs">
          <div
            className={`w-1.5 h-1.5 rounded-full ${connected ? 'bg-green-400' : 'bg-red-400'}`}
            style={{ boxShadow: connected ? '0 0 6px #34d399' : '0 0 6px #ef4444' }}
          />
          <span className="text-white/30 font-mono">{connected ? 'Connected' : 'Disconnected'}</span>
        </div>
      </div>

      <div className="card">
        {events.length === 0 ? (
          <div className="text-center py-16">
            <Activity size={32} className="text-white/10 mx-auto mb-3" />
            <p className="text-white/20 text-sm">No events yet</p>
            <p className="text-white/10 text-xs mt-1">Start a pipeline to see live events here</p>
          </div>
        ) : (
          <div className="space-y-1 max-h-[70vh] overflow-y-auto">
            {[...events].reverse().map((ev, i) => (
              <div
                key={i}
                className="flex items-start gap-3 py-2 px-3 rounded-lg hover:bg-bg-surface2 transition-colors"
              >
                <span className="text-[10px] text-white/20 font-mono shrink-0 mt-0.5 w-20">
                  {new Date(ev.timestamp).toLocaleTimeString()}
                </span>

                <div
                  className={`w-1.5 h-1.5 rounded-full mt-1.5 shrink-0 ${
                    ev.event.includes('failed')
                      ? 'bg-accent-red'
                      : ev.event.includes('completed')
                      ? 'bg-accent-green'
                      : ev.event.includes('started')
                      ? 'bg-accent-blue'
                      : 'bg-white/20'
                  }`}
                />

                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs font-mono text-accent-blue/70">
                      [{ev.agent_type || 'system'}]
                    </span>
                    <span className="text-xs font-medium text-white/70">{ev.event}</span>
                    {ev.project_id && (
                      <span className="text-[10px] font-mono text-white/15">
                        {ev.project_id.slice(0, 8)}...
                      </span>
                    )}
                  </div>
                  {ev.data && Object.keys(ev.data).length > 0 && (
                    <pre className="text-[10px] font-mono text-white/20 mt-1 truncate max-w-xl">
                      {JSON.stringify(ev.data).slice(0, 200)}
                    </pre>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
