import { useEffect, useState } from 'react';
import { Settings, Server, Database, Key, ExternalLink } from 'lucide-react';
import { healthApi } from '../services/api';

export default function SettingsPage() {
  const [health, setHealth] = useState(null);

  useEffect(() => {
    healthApi.check().then(setHealth).catch(() => setHealth({ status: 'offline' }));
  }, []);

  const configItems = [
    { label: 'ANTHROPIC_API_KEY', status: 'required', description: 'Claude API key for all agents' },
    { label: 'SHOPIFY_API_KEY', status: 'required', description: 'Shopify Admin API credentials' },
    { label: 'SHOPIFY_API_SECRET', status: 'required', description: 'Shopify API secret' },
    { label: 'SHOPIFY_ACCESS_TOKEN', status: 'required', description: 'Store access token' },
    { label: 'SHOPIFY_SHOP_URL', status: 'required', description: 'Your .myshopify.com URL' },
    { label: 'OPENAI_API_KEY', status: 'optional', description: 'For AI image generation (DALL-E)' },
    { label: 'DATABASE_URL', status: 'auto', description: 'PostgreSQL connection string' },
    { label: 'REDIS_URL', status: 'auto', description: 'Redis connection string' },
  ];

  return (
    <div className="space-y-8 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Settings</h1>
        <p className="text-sm text-white/40 mt-1">System configuration and API keys</p>
      </div>

      {/* System Status */}
      <div className="card">
        <div className="flex items-center gap-3 mb-4">
          <Server size={18} className="text-white/40" />
          <h2 className="text-base font-semibold">System Status</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-bg-surface2 rounded-xl p-4 border border-border">
            <p className="text-xs text-white/40 mb-1">Backend API</p>
            <div className="flex items-center gap-2">
              <div
                className={`w-2 h-2 rounded-full ${
                  health?.status === 'healthy' ? 'bg-green-400' : 'bg-red-400'
                }`}
              />
              <span className="text-sm font-medium">
                {health?.status === 'healthy' ? 'Online' : 'Offline'}
              </span>
            </div>
          </div>
          <div className="bg-bg-surface2 rounded-xl p-4 border border-border">
            <p className="text-xs text-white/40 mb-1">Environment</p>
            <p className="text-sm font-medium font-mono">{health?.env || 'unknown'}</p>
          </div>
          <div className="bg-bg-surface2 rounded-xl p-4 border border-border">
            <p className="text-xs text-white/40 mb-1">App Name</p>
            <p className="text-sm font-medium font-mono">{health?.app || 'unknown'}</p>
          </div>
        </div>
      </div>

      {/* API Configuration */}
      <div className="card">
        <div className="flex items-center gap-3 mb-4">
          <Key size={18} className="text-white/40" />
          <h2 className="text-base font-semibold">API Configuration</h2>
        </div>
        <p className="text-xs text-white/30 mb-4">
          Configure these in your <code className="bg-bg-surface2 px-1.5 py-0.5 rounded">.env</code> file.
          See <code className="bg-bg-surface2 px-1.5 py-0.5 rounded">.env.example</code> for reference.
        </p>

        <div className="space-y-2">
          {configItems.map((item) => (
            <div
              key={item.label}
              className="flex items-center justify-between py-3 px-4 bg-bg-surface2 rounded-xl border border-border"
            >
              <div>
                <code className="text-xs font-mono font-semibold text-white/70">{item.label}</code>
                <p className="text-[11px] text-white/30 mt-0.5">{item.description}</p>
              </div>
              <span
                className={`badge border ${
                  item.status === 'required'
                    ? 'text-accent-amber bg-accent-amber/10 border-accent-amber/20'
                    : item.status === 'optional'
                    ? 'text-white/40 bg-white/5 border-white/10'
                    : 'text-accent-green bg-accent-green/10 border-accent-green/20'
                }`}
              >
                {item.status}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Links */}
      <div className="card">
        <h2 className="text-base font-semibold mb-4">Useful Links</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {[
            { label: 'Anthropic Console', url: 'https://console.anthropic.com/' },
            { label: 'Shopify Partners', url: 'https://partners.shopify.com/' },
            { label: 'OpenAI Platform', url: 'https://platform.openai.com/' },
            { label: 'API Docs (Swagger)', url: 'http://localhost:8000/docs' },
          ].map(({ label, url }) => (
            <a
              key={label}
              href={url}
              target="_blank"
              rel="noopener"
              className="flex items-center justify-between py-3 px-4 bg-bg-surface2 rounded-xl border border-border
                         hover:border-border-glow transition-colors group"
            >
              <span className="text-sm text-white/60 group-hover:text-white/80">{label}</span>
              <ExternalLink size={14} className="text-white/20 group-hover:text-white/40" />
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}
